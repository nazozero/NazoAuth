# Sanitized A3000 steady evidence

This archive contains aggregate gate outputs, sanitized PostgreSQL snapshots, and measurement-window numeric sampler streams. SQL query text is removed and replaced with SHA-256 identifiers; audit/journal payloads, request-level logs, secrets, DSNs, host-level memory fields, and process command lines are excluded. summary.json distinguishes the exact 1,800-second measurement window from the broader pre/post PostgreSQL snapshots. Missing evidence remains invalid or not verified rather than being filled with zero.
