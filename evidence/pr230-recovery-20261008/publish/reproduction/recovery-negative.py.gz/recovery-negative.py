from pathlib import Path
import subprocess,os,json,time,datetime,hashlib,fcntl,re
R=Path('/src/evidence/pr230-recovery-20261008');A='e13fcfd1292283f135906a31de987b533f002de8';B='bea8a7e0dd608b91b94000003fe5370508979d99';branch='refactor/authorization-decision-facts-20261001'
lock=open('/src/.git/recovery-validation.lock','w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
env=dict(os.environ,**json.loads((R/'private-test-env.json').read_text()),PYTHONHOME='/opt/python314',LD_LIBRARY_PATH='/opt/python314/lib');env['PATH']='/opt/python314/bin:'+env['PATH']
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def run(label,cmd):
 log=R/(label+'.log');assert not log.exists();start=time.monotonic()
 with log.open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'sha':git('rev-parse','HEAD'),'label':label,'command':cmd,'exit':r.returncode,'seconds':time.monotonic()-start,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 with (R/'commands.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
 print(json.dumps(rec),log.read_text()[-2200:],flush=True);return r.returncode,log.read_text()
assert git('rev-parse','HEAD')==B and not git('diff','--name-only')
for label,cmd in [('B-initial-static',['python3.14','scripts/verify_static_contracts.py','--check']),('B-initial-dependency',['python3.14','scripts/check_persistence_dependency_graph.py']),('B-initial-fmt',['cargo','fmt','--check'])]:run(label,cmd)
tests=['crates/nazoauth/tests/unit/adapters/audit/recovery.rs','crates/persistence-postgres/tests/security_state_commit_boundary.rs'];audit='crates/nazoauth/src/adapters/audit.rs'
subprocess.run(['git','switch','--detach',A],check=True,capture_output=True)
results={}
try:
 for name in tests:
  s=(R/'negative-overlay'/name).read_text()
  if name==tests[0]:
   start=s.index('#[test]\nfn telemetry_expiry_uses_required_lag_boundary');end=s.index('#[tokio::test',start);s=s[:start]+s[end:]
  Path(name).parent.mkdir(parents=True,exist_ok=True);Path(name).write_text(s)
  (R/('A-overlay-'+Path(name).name)).write_text(s)
 p=Path(audit);p.write_text(p.read_text()+'\n#[cfg(test)]\n#[path = "../../tests/unit/adapters/audit/recovery.rs"]\nmod recovery_tests;\n')
 (R/'A-negative-mount.patch').write_text(git('diff','--',audit)+'\n')
 results['recovery']=run('A-negative-recovery',['cargo','test','--all-features','--locked','-p','nazoauth','--lib','recovery_tests','--','--nocapture'])
 results['cleanup']=run('A-negative-cleanup',['cargo','test','--all-features','--locked','-p','nazo-postgres','--test','security_state_commit_boundary','--','--nocapture'])
finally:
 subprocess.run(['git','restore','--source='+A,'--worktree','--',audit],check=True)
 for name in tests:Path(name).unlink()
 subprocess.run(['git','switch',branch],check=True,capture_output=True)
 assert git('rev-parse','HEAD')==B and not git('diff','--name-only')
proof={k:{'exit':v[0],'runtime_test_result':re.findall(r'test result:.*',v[1]),'compiled_test_failure':v[0]==101 and 'test result: FAILED.' in v[1]} for k,v in results.items()}
(R/'negative-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof),flush=True)
assert all(v['compiled_test_failure'] for v in proof.values()),'Not valid runtime negative proof; inspect logs'
