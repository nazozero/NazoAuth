from pathlib import Path
import tarfile,subprocess,json,hashlib,datetime
R=Path('/src/evidence/pr230-recovery-20261008');d=R/'private-tools';p=d/'node-v26.10.0-linux-x64.tar.xz';expected=next(l.split()[0] for l in (d/'node-SHASUMS256.txt').read_text().splitlines() if l.endswith(' '+p.name));assert hashlib.sha256(p.read_bytes()).hexdigest()==expected
with tarfile.open(p,'r:xz') as t:t.extractall(d,filter='data')
q=subprocess.run([str(d/'node-v26.10.0-linux-x64/bin/node'),'--version'],capture_output=True,text=True);assert q.returncode==0 and q.stdout.strip()=='v26.10.0'
record={'version':q.stdout.strip(),'archive_url':'https://nodejs.org/dist/v26.10.0/'+p.name,'sha256':expected,'matches_official_shasums':True,'extract':'Python stdlib tarfile r:xz with data filter; shell tar failed because xz executable absent','exit':q.returncode,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};(R/'node-fixture.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
