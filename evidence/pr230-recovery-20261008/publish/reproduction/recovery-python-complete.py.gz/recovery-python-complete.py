from pathlib import Path
import subprocess,os,json,time,datetime,hashlib
R=Path('/src/evidence/pr230-recovery-20261008');env=dict(os.environ,**json.loads((R/'private-test-env.json').read_text()),PYTHONHOME='/opt/python314',LD_LIBRARY_PATH='/opt/python314/lib');env['PATH']=str(R/'private-tools/node-v26.10.0-linux-x64/bin')+':'+str(R/'private-tools')+':/opt/python314/bin:'+env['PATH'];sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();gates=json.loads((R/'final-gates.json').read_text());cmd=next(x['command'] for x in gates if x['label']=='perf-python');cmd=cmd[:3]+['-v']+cmd[3:]
for tool in ['node','k6']:
 q=subprocess.run([tool,'--version' if tool=='node' else 'version'],env=env,capture_output=True,text=True);print(tool,q.returncode,q.stdout.strip());assert q.returncode==0
for label,command in [('python-compile',['python','-m','compileall','-q','scripts','perf']),('perf-python',cmd)]:
 log=R/('final-'+label+'-complete.log');assert not log.exists();start=time.monotonic()
 with log.open('w') as f:r=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT)
 record={'sha':sha,'label':label,'command':command,'exit':r.returncode,'seconds':time.monotonic()-start,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'fixture':'Python3.14.8,orjson3.12.0,Node26.10.0 and exact pinned performance k6 binary; no skipped producer tests accepted'}
 gates.append(record);(R/'final-gates.json').write_text(json.dumps(gates,indent=2)+'\n')
 with (R/'commands.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
 print(json.dumps(record),log.read_text()[-1500:],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 if label=='perf-python':assert 'skipped=' not in log.read_text(),'missing fixture/skip cannot count as acceptance'
