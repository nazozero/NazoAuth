from pathlib import Path
import subprocess,os,json,time,datetime,hashlib,fcntl
R=Path('/src/evidence/pr230-recovery-20261008');lock=open('/src/.git/recovery-validation.lock','w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
env=dict(os.environ,**json.loads((R/'private-test-env.json').read_text()),PYTHONHOME='/opt/python314',LD_LIBRARY_PATH='/opt/python314/lib');env['PATH']='/opt/python314/bin:'+env['PATH'];sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
cmds=[('static',['python','scripts/verify_static_contracts.py','--check']),('dependency',['python','scripts/check_persistence_dependency_graph.py']),('crypto',['python','scripts/check_crypto_boundary.py']),('crypto-tests',['python','-m','unittest','discover','-s','scripts','-p','test_crypto_boundary.py']),('perf-layout',['python','scripts/check_perf_results_layout.py']),('fmt',['cargo','fmt','--check']),('clippy',['cargo','clippy','--workspace','--all-targets','--all-features','--locked','--keep-going','--','-D','warnings']),('migration',['cargo','test','--all-features','--locked','-p','nazo-postgres','--test','migrations','pending_migrations_create_all_runtime_module_state_tables']),('workspace',['cargo','test','--workspace','--all-features','--locked','--no-fail-fast']),('perf-python',['python','-m','unittest']+['perf.tests.'+x for x in ['test_blackbox_contract','test_capacity_window','test_capacity_producer','test_stream_cohort','test_single_instance_scaling','test_service_affinity','test_cnb_controller','test_pool_size_ab','test_issuance_maintenance','test_evidence_contract','test_audit_reconciliation','test_audit_pending_schema','test_current_capacity','test_short_baseline','test_checkpoint_measurement.WindowContractTest']])]
results=[]
for label,cmd in cmds:
 log=R/('final-'+label+'.log');assert not log.exists();start=time.monotonic()
 with log.open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'sha':sha,'label':label,'command':cmd,'exit':r.returncode,'seconds':time.monotonic()-start,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()};results.append(rec)
 with (R/'commands.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
 (R/'final-gates.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(rec),log.read_text()[-2000:],flush=True)
 if r.returncode and label!='workspace':raise SystemExit(r.returncode)
raise SystemExit(1 if any(x['exit'] for x in results) else 0)
