from pathlib import Path
import json,math,statistics,hashlib,shutil
E=Path('evidence/pr230-recovery-20261008');pub=E/'publish';pub.mkdir(exist_ok=True);out=[]
def load(p):return json.loads(p.read_text())
def lines(p):return [json.loads(l) for l in p.read_text().splitlines()] if p.exists() else []
for base in sorted((E/'perf').iterdir()):
 paths=list(base.glob('results/*/*/short-result.json'))
 if not paths:continue
 if base.name.startswith(('fault','policy')):continue
 p=paths[0];root=p.parent;r=load(p)
 if r.get('verdict')=='INVALID':
  out.append({'point':base.name,'verdict':'INVALID','reason':r.get('metrics',{}).get('reason')});continue
 m=r.get('metrics',{});measure=m.get('measure',{});cost=r.get('cost',{});samples=lines(root/'revision-storage.jsonl');samples=[s for s in samples if 'pending' in s]
 row={'point':base.name,'verdict':r.get('verdict'),'source_sha':load(root/'provenance.json').get('app_source_sha_file'),'ops_s':m.get('successful_ops_s'),'latency_ms':m.get('complete_operation_latency_ms'),'dropped':measure.get('measure_dropped_exact'),'started':measure.get('measure_started_exact'),'completed':measure.get('measure_completed_exact'),'outcomes':measure.get('measure_outcomes'),'wal_per_success':cost.get('wal_per_success_bytes'),'cpu_cores':r.get('component_cpu_cores'),'unverified_internal_gates':r.get('unverified_internal_gates'),'collector_complete':r.get('health',{}).get('collector_copy_complete')}
 row['diagnostic_only']=base.name.endswith('diagnostic')
 row['measure_raw']=measure
 row['unfinished']=measure.get('measure_started_exact',0)-measure.get('measure_completed_exact',0)
 row['unexpected_errors']=m.get('unexpected_errors')
 row['expected_invalid_grant']=m.get('expected_invalid_grant')
 row['drop_fraction']=measure.get('measure_drop_fraction')
 row['started_success_fraction']=measure.get('measure_outcomes',{}).get('success',0)/measure['measure_started_exact'] if measure.get('measure_started_exact') else None
 row['valkey_bytes']=load(root/'vkledger-post.json')['info']['used_memory']
 if base.name=='p03-H1':row['comparison_validity']='INVALID: FAPI sidecar 270 unexpected invalid_dpop_proof errors; main-only success metrics exclude failed required sidecar work.'
 row['main_verdict']=m.get('main_verdict');row['sidecars']={name:{'verdict':v['verdict'],'ops_s':v['metrics'].get('successful_ops_s'),'latency_ms':v['metrics'].get('complete_operation_latency_ms'),'dropped':v['metrics'].get('measure',{}).get('measure_dropped_exact'),'outcomes':v['metrics'].get('measure',{}).get('measure_outcomes')} for name,v in m.get('sidecar_gates',{}).items()}
 if samples:
  fields=['pending','oldest_pending_s','family_eligible','family_live','contract_orphan','decision_eligible','decision_retained','spent_eligible','spent_retained','db_bytes']
  row['storage']={'span_s':samples[-1]['ts']-samples[0]['ts'],'first':{k:samples[0].get(k) for k in fields},'last':{k:samples[-1].get(k) for k in fields},'max':{k:max(s.get(k,0) or 0 for s in samples) for k in fields},'physical_db_delta_bytes':samples[-1]['db_bytes']-samples[0]['db_bytes']}
  row['storage']['live_samples']=[{k:s.get(k) for k in ['ts','pending','oldest_pending_s','family_eligible','contract_orphan','decision_eligible','spent_eligible']} for s in samples]
 before=load(root/'pgss-pre.json');after=load(root/'pgss-post.json');dt=float(after['ts'])-float(before['ts']);index={(s['queryid'],s.get('toplevel'),s.get('userid')):s for s in before['statements']};sql=[]
 for s in after['statements']:
  if not s.get('toplevel'):continue
  if not any(t in s['q'] for t in ['nazo_persist_security_audit','nazo_append_security_audit','nazo_observe_security_audit','nazo_ack_security_audit','nazo_security_audit_shared_privilege_preflight','head_sequence','nazo_claim_security_audit','nazo_finalize_security_audit','nazo_commit_authorization_decision']):continue
  old=index.get((s['queryid'],s.get('toplevel'),s.get('userid')),{});n=s['calls']-old.get('calls',0);ms=s['total_exec_time']-old.get('total_exec_time',0);sql.append({'role':s.get('rolname'),'query':s['q'],'calls':n,'calls_s':n/dt,'total_exec_ms':ms,'mean_exec_ms':ms/n if n else None,'rows':s['rows']-old.get('rows',0)})
 row['sql']={'observation_s':dt,'statements':sql}
 row['exported_events']=r.get('audit',{}).get('delta_events');row['exported_batches']=r.get('audit',{}).get('journal',{}).get('batches');row['exported_mean_batch']=row['exported_events']/row['exported_batches'] if row['exported_batches'] else None
 series=next((root/'load').glob('*.series.json'),None);trends=[]
 if series:
  data=load(series);start=measure['window_start_s'];end=measure['window_end_s'];bounds=data['hist_bounds_ms'];buckets={}
  for ts,b in data['bins'].items():
   if not start<=float(ts)<end:continue
   h=b['cap_iter_ms'];n=h['n'];i=int((float(ts)-start)//10);bucket=buckets.setdefault(i,{'n':0,'b':[0]*len(h['b']),'max':0,'mean_sum':0,'http_errors':0,'drop':0});bucket['n']+=n;bucket['b']=[a+z for a,z in zip(bucket['b'],h['b'])];bucket['max']=max(bucket['max'],h.get('max') or 0);bucket['mean_sum']+=h['sum'];bucket['http_errors']+=b.get('http_req_failed',0);bucket['drop']+=b.get('dropped',0)
  for i,b in sorted(buckets.items()):
   cum=0;bound=None
   for j,n in enumerate(b['b']):
    cum+=n
    if cum>=.99*b['n']:bound=bounds[j] if j<len(bounds) else 'over_10000';break
   trends.append({'from_s':i*10,'n':b['n'],'p99_hist_upper_ms':bound,'max_ms':b['max'],'mean_ms':b['mean_sum']/b['n'] if b['n'] else None,'drop':b['drop'],'http_errors':b['http_errors']})
 row['latency_trend_10s_histogram']=trends
 if (base/'low-required.json').exists():
  low=load(base/'low-required.json');values=sorted(x['ms'] for x in low['rows']);row['low_required']={'n':len(values),'successes':low['successes'],'p50':values[math.ceil(.5*len(values))-1],'p95':values[math.ceil(.95*len(values))-1],'p99':values[math.ceil(.99*len(values))-1]}
 dest=pub/base.name;dest.mkdir(exist_ok=True)
 for leaf in ['short-result.json','provenance.json','revision-storage.jsonl','soak-metrics.jsonl','proc-detail.jsonl','pgss-pre.json','pgss-post.json','task-cleanup.json','task-finalization.json','task-audit-preflight.json','vkledger-post.json']:
  if (root/leaf).exists():shutil.copy2(root/leaf,dest/leaf)
 for leaf in ['low-required.json','low-required-audit.json','sql-cost-series.jsonl','pg-waits.jsonl']:
  if (base/leaf).exists():shutil.copy2(base/leaf,dest/leaf)
 for file in (root/'load').glob('*.series.json'):shutil.copy2(file,dest/file.name)
 out.append(row)
(pub/'ab-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
for r in out:print(json.dumps({k:r.get(k) for k in ['point','verdict','ops_s','latency_ms','dropped']}))



