from pathlib import Path
import json,csv,statistics,hashlib,shutil
E=Path('/src/evidence/pr230-recovery-20261008');P=E/'publish'
rows=json.loads((P/'ab-analysis.json').read_text())
for row in rows:
 if row['verdict']=='INVALID':continue
 key=row['point'];root=P/key
 samples=[json.loads(s) for s in (root/'revision-storage.jsonl').read_text().splitlines() if s] if (root/'revision-storage.jsonl').exists() else []
 if not samples:continue
 full=json.loads((root/'short-result.json').read_text());window=full['metrics']['measure'];start=window['window_start_s'];end=window['window_end_s']
 live=[s for s in samples if start<=s.get('ts',0)<=end and 'pending' in s]
 def fit(a,k):
  a=[s for s in a if s.get(k) is not None]
  if len(a)<2:return None
  x=[s['ts']-a[0]['ts'] for s in a];y=[s[k] for s in a];mx=statistics.mean(x);my=statistics.mean(y);den=sum((v-mx)**2 for v in x)
  return sum((v-mx)*(w-my) for v,w in zip(x,y))/den if den else None
 row['formal_storage']={'samples':len(live),'window_seconds':end-start,'first':live[0] if live else None,'last':live[-1] if live else None,'linear_rates_per_s':{k:fit(live,k) for k in ['pending','family_eligible','decision_eligible','spent_eligible','db_bytes']},'note':'OLS rates describe this bounded window; periodic cleanup and physical allocation require the full series, not a slope-only verdict.'}
 with (root/'storage-series.csv').open('w') as f:
  cols=['ts','phase','formal','pending','oldest_pending_s','family_eligible','family_live','contract_orphan','decision_eligible','decision_retained','spent_eligible','spent_retained','db_bytes'];w=csv.DictWriter(f,fieldnames=cols);w.writeheader()
  for s in samples:
   if 'pending' in s:w.writerow({k:(start<=s['ts']<=end if k=='formal' else s.get(k)) for k in cols})
 proc=[json.loads(s) for s in (root/'proc-detail.jsonl').read_text().splitlines() if s] if (root/'proc-detail.jsonl').exists() else []
 rss=[s['app']['rss_kb'] for s in proc if s.get('app',{}).get('rss_kb') is not None]
 row['app_rss_kb']={'first':rss[0],'last':rss[-1],'max':max(rss)} if rss else None
(P/'ab-analysis.json').write_text(json.dumps(rows,indent=2)+chr(10))
# Keep raw cost intervals and strictly selected maintenance messages, without application payloads.
for key in ['sustained-A','sustained-B']:
 base=E/'perf'/key;out=P/key;out.mkdir(exist_ok=True)
 for leaf in ['sql-cost-series.jsonl','pg-waits.jsonl','maintenance.log','pool-acquisition.log.gz','required-mode-verification.json','low-required.json','low-required-audit.json']:
  if (base/leaf).exists():shutil.copy2(base/leaf,out/leaf)
print('Added formal storage windows, raw CSV and process RSS summaries')


