from pathlib import Path
import gzip,json,datetime,hashlib,math,collections
R=Path('/src/evidence/pr230-recovery-20261008');P=R/'publish';output=[]
def quant(v,q):
 v=sorted(v);x=(len(v)-1)*q;i=int(x);return v[i]+(v[min(i+1,len(v)-1)]-v[i])*(x-i) if v else None
for key in ['p06-A','p06-B','p10-A','p10-B','p03-A','p03-B','p04-A','p04-B']:
 root=next((R/'perf'/key).glob('results/*/*/short-result.json')).parent;d=json.loads((root/'short-result.json').read_text());m=d['metrics']['measure'];p=next((root/'load').glob('*.diag.jsonl.gz'));values=[];bins=collections.defaultdict(list);count=0
 with gzip.open(p,'rt') as f,gzip.open(P/key/'full-operation-latencies.jsonl.gz','wt') as out:
  for line in f:
   if '"metric":"cap_iter_ms"' not in line:continue
   a=json.loads(line)['data'];ts=datetime.datetime.fromisoformat(a['time'].replace('Z','+00:00')).timestamp();v=a['value'];values.append(v);i=int((ts-m['window_start_s'])//10);bins[i].append(v);out.write(json.dumps({'completion_ts':ts,'full_operation_ms':v})+'\n')
 q={k:quant(values,v) for k,v in [('p50',.5),('p95',.95),('p99',.99)]};row={'point':key,'raw_compressed_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'raw_compressed_bytes':p.stat().st_size,'n':len(values),'formal_completed':m['measure_completed_exact'],'complete_cohort_count_matches':len(values)==m['measure_completed_exact'],'quantiles':q,'reported_quantiles':d['metrics']['complete_operation_latency_ms'],'completion_time_bins':[{'from_s':i*10,'n':len(v),'p50':quant(v,.5),'p95':quant(v,.95),'p99':quant(v,.99),'max':max(v)} for i,v in sorted(bins.items())],'limits':'Exact full-operation values of measurement cohort; trend buckets use completion time relative to formal window and include its drain tail, not arrival cohorts. Original capacity verdict unchanged.'};
 if len(values)!=m['measure_completed_exact']:
  (P/key/'full-operation-latencies.jsonl.gz').rename(P/key/'forensic-operation-latencies.partial.jsonl.gz')
  row['forensic_subset_quantiles']=row.pop('quantiles');row['recalculation_verdict']='INVALID';row['limits']='Bounded forensic diagnostic archive does not retain all latency points; these subset quantiles must not replace full-stream formal cohort metrics. Original window/analyzer evidence has valid full-stream accounting; capacity verdict unchanged.'
 else:row['recalculation_verdict']='PASS'
 output.append(row)
 print(key, len(values), row['complete_cohort_count_matches'], q)
(P/'complete-operation-latency-analysis.json').write_text(json.dumps(output,indent=2)+'\n')
