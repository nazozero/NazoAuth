from pathlib import Path
import json,collections
R=Path('/src/evidence/pr230-recovery-20261008');P=R/'publish';lat={x['point']:x for x in json.loads((P/'sustained-latency-analysis.json').read_text())};out=[]
for key in ['sustained-A','sustained-B']:
 root=next((R/'perf'/key).glob('results/*/*/short-result.json')).parent;m=json.loads((root/'short-result.json').read_text())['metrics']['measure'];lo=m['window_start_s'];s=[json.loads(l) for l in (R/'perf'/key/'app-schedstat.jsonl').read_text().splitlines()];db=[json.loads(l) for l in (root/'revision-storage.jsonl').read_text().splitlines()];rows=[]
 for b in lat[key]['completion_time_bins']:
  start=lo+b['from_s'];end=start+10;a=[v for v in s if start<=v['ts']<end];z=[v for v in db if start<=v['ts']<end];row=dict(b)
  if len(a)>1:
   first,last=a[0],a[-1];ids=set(first['tasks'])&set(last['tasks']);row['sched_interval_s']=last['ts']-first['ts'];row['runtime_s']=sum(last['tasks'][i][0]-first['tasks'][i][0] for i in ids)/1e9;row['runnable_wait_s']=sum(last['tasks'][i][1]-first['tasks'][i][1] for i in ids)/1e9
  if z:
   row['family_eligible']=[z[0]['family_eligible'],z[-1]['family_eligible']];row['decision_eligible']=[z[0]['decision_eligible'],z[-1]['decision_eligible']];row['oldest_pending_s_max']=max(v['oldest_pending_s'] for v in z);row['deletions_observed']={name:next(t for t in z[-1]['tables'] if t['relname']==name)['n_tup_del']-next(t for t in z[0]['tables'] if t['relname']==name)['n_tup_del'] for name in ['oauth_refresh_families','security_audit_events']}
  rows.append(row)
 out.append({'point':key,'bins':rows,'limits':'Intervals are sampled subsets of the same 10-second completion buckets; no causal attribution from correlation. security_audit_events deletion includes export cleanup and retained-decision GC.'});print(key,json.dumps(rows[-5:],indent=2))
(P/'sustained-correlated-series.json').write_text(json.dumps(out,indent=2)+'\n')
