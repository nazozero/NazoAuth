from pathlib import Path
import json,re,collections,datetime,base64,hashlib,csv,gzip,shutil
R=Path('/src/evidence/pr230-recovery-20261008')
for result in (R/'perf').rglob('fault-result.json'):
 root=result.parent;key=root.parts[root.parts.index('perf')+1];pub=R/'publish'/key;pub.mkdir(parents=True,exist_ok=True);d=json.loads(result.read_text())
 if not (root/'fault-storage-http.jsonl').exists():continue
 rows=[json.loads(l) for l in (root/'fault-storage-http.jsonl').read_text().splitlines()];ss=[s for s in rows if s.get('kind')=='sample'];http=[x for s in ss for x in s['http']];schedule=d['schedule'];stop=schedule['stop_at']
 text=re.sub(r'\x1b\[[0-9;]*m','',(root/'app.log').read_text());logs=[]
 for l in text.splitlines():
  if 'audit.persistence:' not in l:continue
  status=re.search(r'persistence_status="([^"]+)"',l)
  if not status:continue
  kind=status[1];count=re.search(r'(?:discarded_events|batch_len)=(\d+)',l);eid=re.search(r'first_event_id=([\w-]+)',l)
  if kind=='not_queued' and 'queue_full' not in l:continue
  logs.append({'ts':datetime.datetime.fromisoformat(l.split()[0].replace('Z','+00:00')).timestamp(),'kind':kind,'count':int(count[1]) if count else 1,'first_event_id':eid[1] if eid else None})
 counts=collections.Counter()
 for x in logs:counts[x['kind']]+=x['count']
 journal=[json.loads(l) for l in (root/'receiver-journal.private.jsonl').read_text().splitlines()];events=[e for j in journal for e in j.get('events',[])];ids=collections.Counter(e['event_id'] for e in events);seqs=[e['sequence'] for e in events];bytype=collections.Counter(e['event_type'] for e in events);unique={e['event_id']:e for e in events}
 identity=[{k:e[k] for k in ['event_id','sequence','event_type','occurred_at','event_hash']}|{'payload_sha256':hashlib.sha256(e['payload_canonical'].encode()).hexdigest()} for e in unique.values()]
 eventmap={e['event_id']:e for e in identity}
 for x in logs:
  if x['kind']=='durable' and x['first_event_id'] in eventmap:x['first_event_age_at_confirmation_s']=x['ts']-datetime.datetime.fromisoformat(eventmap[x['first_event_id']]['occurred_at'].replace('Z','+00:00')).timestamp()
 starts=[0]+sorted(map(int,schedule['faults']))+[stop,schedule['observe_until']+1];ph=[]
 for a,b in zip(starts,starts[1:]):
  h=[x for x in http if a<=x.get('seconds',-1)<b];required=[x for x in h if x['kind']=='required'];st=[s['storage'] for s in ss if a<=s['second']<b and 'storage' in s];longest=cur=0
  for x in required:cur=cur+1 if x.get('status')==503 else 0;longest=max(cur,longest)
  suffix=0
  for x in reversed(required):
   if x.get('status')==200:suffix+=1
   else:break
  ph.append({'start':a,'end':b,'http':{f'{k}:{v}':n for (k,v),n in collections.Counter((x['kind'],x.get('status')) for x in h).items()},'longest_consecutive_required_503':longest,'ending_consecutive_required_200':suffix,'oldest_pending_max_s':max((x['oldest_pending_s'] for x in st),default=0),'pending_first_last': [st[0]['pending'],st[-1]['pending']] if st else None})
 produced=sum(x.get('kind')=='telemetry' and x.get('status')==200 for x in http);required=sum(x.get('kind')=='required' and x.get('status')==200 for x in http);expired=counts['expired_unattempted_telemetry'];unavailable=counts['unavailable_export_unattempted_telemetry'];queue=counts['not_queued'];durable=counts['durable'];residual=produced+required-expired-unavailable-queue-durable
 final=d['audit_final'];db=final['db'];cp=final['receiver_checkpoint'];hashhex=base64.urlsafe_b64decode(cp['last_hash']+'='*(-len(cp['last_hash'])%4)).hex()
 checks={'execution':d.get('load_exit')==0 and not d.get('error'),'sequence_contiguous':sorted(seqs)==list(range(1,db['last_sequence']+1)),'event_ids_unique':len(ids)==len(events),'db_receiver_anchor_agree':db['last_sequence']==db['anchor_sequence']==cp['last_sequence']==len(events) and db['last_hash']==db['anchor_hash']==hashhex,'pending_zero':db['pending']==0,'worker_confirmations_match_receiver':durable==len(events)-bytype['dynamic_client_registered'],'required_delivered':bytype['mtls_trust_bundle_exported']==required,'queue_accounting_converged':residual==0}
 pg=json.loads((root/'pgss-post.json').read_text());calls=[x for x in pg['statements'] if any(n in x['q'] for n in ['nazo_persist_security_audit','nazo_append_security_audit','nazo_ack_security_audit','nazo_observe_security_audit'])]
 recovery=[]
 origin=ss[0]['ts']-ss[0]['second']
 for a,b in zip(starts,starts[1:]):
  if str(a) not in schedule['faults'] or schedule['faults'][str(a)]!='none':continue
  old_max=max((e['sequence'] for e in events if datetime.datetime.fromisoformat(e['occurred_at'].replace('Z','+00:00')).timestamp()<=origin+a),default=0)
  safe=next((s for s in ss if a<=s['second']<b and 'storage' in s and s['storage']['anchor']>=old_max and s['storage']['oldest_pending_s']<=10 and not s['storage']['blocked'] and s['storage']['observed_at'] is not None and s['ts']-s['storage']['observed_at']<=10),None)
  h=[x for x in http if x['kind']=='required' and safe and safe['second']<=x.get('seconds',-1)<min(b,stop)]
  recovery.append({'from':a,'to':min(b,stop),'pre_recovery_persisted_max_sequence':old_max,'first_confirmed_healthy_sample_second':safe['second'] if safe else None,'active_observation_s':min(b,stop)-safe['second'] if safe else 0,'required_statuses':dict(collections.Counter(str(x.get('status')) for x in h)),'required_all_success_after_confirmed_drain':bool(h) and all(x.get('status')==200 for x in h)})
 if d['app_audit_configuration']['AUDIT_ANCHOR_MODE']=='required':checks['sustained_recovery']=all(x['active_observation_s']>=20 and x['required_all_success_after_confirmed_drain'] for x in recovery) and bool(recovery)
 pre=json.loads((root/'pgss-pre.json').read_text());idx={(x['queryid'],x.get('userid'),x.get('toplevel')):x for x in pre['statements']}
 calls=[dict(x,pre_calls=idx.get((x['queryid'],x.get('userid'),x.get('toplevel')),{}).get('calls',0),delta_calls=x['calls']-idx.get((x['queryid'],x.get('userid'),x.get('toplevel')),{}).get('calls',0)) for x in calls]
 summary={'source_sha':d['source_sha'],'schedule':schedule,'checks':checks,'phases':ph,'accounting':{'telemetry_http200':produced,'required_http200':required,'queue_full':queue,'expired_unattempted':expired,'closed_export_unattempted':unavailable,'confirmed_worker_events':durable,'inferred_inflight_end':residual,'receiver_unique_types':dict(bytype),'duplicate_event_ids':sum(n-1 for n in ids.values()),'receiver_duplicate_envelope_requests':final['receiver_state']['duplicates'],'http_drops':sum(x.get('drop',0) for x in http)},'database_calls':calls,'recovery_after_confirmed_drain':recovery,'final':final,'drain':d['drain'],'max_first_event_age_at_confirmation_s':max((x.get('first_event_age_at_confirmation_s',0) for x in logs if x['kind']=='durable'),default=0),'boundary':'HTTP200 is produced best-effort input, not durability; business registration is separate. Remaining in-flight is an accounting inference, not an internal gauge. SQL stats count completed calls; health-gate retry logs are not append attempts.'}
 (pub/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
 for leaf,data in [('event-identities.jsonl.gz',identity),('audit-persistence-events.jsonl.gz',logs),('fault-storage-http.jsonl.gz',rows)]:
  with gzip.open(pub/leaf,'wt') as f:
   for x in data:f.write(json.dumps(x)+'\n')
 with (pub/'storage-series.csv').open('w') as f:
  cols=['second','ts','pending','oldest_pending_s','anchor','observed_at','blocked','db_bytes','family_eligible','family_live','contract_orphan','decision_eligible','decision_retained','spent_eligible','spent_retained','vk_used_memory'];w=csv.DictWriter(f,fieldnames=cols);w.writeheader()
  for s in ss:
   if 'storage' in s:w.writerow({k:s.get(k,s['storage'].get(k)) for k in cols})
 for leaf in ['pgss-pre.json','pgss-post.json','provenance.json','task-audit-preflight.json','task-container-states-before-cleanup.json','fault-result.json']:
  shutil.copy2(root/leaf,pub/leaf)
 for leaf in ['proc-detail.jsonl','soak-metrics.jsonl','app.log','exporter.log']:
  with (root/leaf).open('rb') as a,gzip.open(pub/(leaf+'.gz'),'wb') as b:shutil.copyfileobj(a,b)
 print(key,json.dumps({'checks':checks,'phases':ph,'accounting':summary['accounting'],'append_age':summary['max_first_event_age_at_confirmation_s']},indent=2))


