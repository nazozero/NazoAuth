from pathlib import Path
import json,gzip,re,datetime,math,statistics,collections,shutil
R=Path('/src/evidence/pr230-recovery-20261008');P=R/'publish';base=R/'perf/p06-diagnostic';root=next(base.glob('results/*/*/short-result.json')).parent
m=json.loads((root/'short-result.json').read_text())['metrics']['measure'];lo=m['window_start_s'];hi=m['window_end_s'];ansi=re.compile(r'\x1b\[[0-9;]*m');rows=[]
with gzip.open(base/'pool-acquisition.log.gz','rt') as f:
 for line in f:
  s=ansi.sub('',line);ts=datetime.datetime.fromisoformat(s.split()[0].replace('Z','+00:00')).timestamp()
  if not lo<=ts<hi:continue
  vals=dict(re.findall(r'(acquire_us|available_before|waiting_before|success)=(\w+)',s));rows.append({'ts':ts,**{k:int(v) if v.isdigit() else v for k,v in vals.items()}})
values=sorted(x['acquire_us']/1000 for x in rows)
def quant(q):return values[max(0,math.ceil(q*len(values))-1)] if values else None
waits=[json.loads(l) for l in (base/'pg-waits.jsonl').read_text().splitlines()];waits=[x for x in waits if lo<=x.get('ts',0)<hi];states=collections.Counter();maxage=0
for x in waits:
 for a in x.get('activity') or []:
  states[(a.get('state'),a.get('wait_event_type'),a.get('wait_event'))]+=a['n'];maxage=max(maxage,a.get('oldest_xact_s') or 0)
maintenance=ansi.sub('',(base/'maintenance.log').read_text());cycles=[l for l in maintenance.splitlines() if 'cycle completed' in l]
out={'scope':'diagnostic-only final B auth code 800/s; 992 VUs; original 15s warmup +60s formal; TRACE overhead, not an A/B acceptance replacement','formal_pool_acquisitions':len(rows),'acquire_ms':{'p50':quant(.5),'p95':quant(.95),'p99':quant(.99),'max':max(values) if values else None,'mean':statistics.mean(values) if values else None},'available_zero_fraction':sum(x['available_before']==0 for x in rows)/len(rows),'waiting_before_max':max(x['waiting_before'] for x in rows),'failed_acquisitions':sum(x['success']!='true' for x in rows),'pg_samples':len(waits),'pg_backend_sample_counts':[{'state':k[0],'wait_event_type':k[1],'wait_event':k[2],'backend_samples':v} for k,v in states.most_common()],'oldest_sampled_transaction_s_max':maxage,'maintenance_cycles':cycles,'limits':'PG waits sampled every second, so brief locks may be missed; runnable wait, SQL time, pool wait overlap and must not be added as mutually exclusive request phases. Pool measures successful acquire elapsed, not pure queue-only duration.'}
(P/'pool-diagnostic-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
for leaf in ['pool-acquisition.log.gz','pg-waits.jsonl','maintenance.log']:
 shutil.copy2(base/leaf,P/'p06-diagnostic'/leaf)
print(json.dumps(out,indent=2))
# Complete storage classifications and observed deletion intervals.
summary=[]
for key in ['sustained-A','sustained-B']:
 b=R/'perf'/key;r=next(b.glob('results/*/*/short-result.json')).parent;series=[json.loads(l) for l in (r/'revision-storage.jsonl').read_text().splitlines()];series=[s for s in series if 'pending' in s];first,last=series[0],series[-1];tables=[]
 for t in last['tables']:
  name=t['relname'];a=next(x for x in first['tables'] if x['relname']==name);timeline=[]
  for prev,nxt in zip(series,series[1:]):
   x=next(t for t in prev['tables'] if t['relname']==name);y=next(t for t in nxt['tables'] if t['relname']==name);delta=y['n_tup_del']-x['n_tup_del']
   if delta:timeline.append({'from_s':prev['ts']-first['ts'],'to_s':nxt['ts']-first['ts'],'deleted':delta,'deleted_per_s':delta/(nxt['ts']-prev['ts'])})
  tables.append({'name':name,'first':a,'last':t,'deletion_intervals':timeline})
 for leaf in ['ledger-pre.txt','ledger-post.txt','point.json','wal-pre.json','wal-post.json','vkledger-pre.json']:
  shutil.copy2(r/leaf,P/key/leaf)
 summary.append({'point':key,'span_s':last['ts']-first['ts'],'stop_samples':sum(s.get('phase')=='stopped_observation' for s in series),'tables':tables,'final':{k:last[k] for k in ['pending','oldest_pending_s','family_eligible','family_live','contract_orphan','decision_eligible','decision_retained','spent_eligible','spent_retained','db_bytes']},'limits':'Last sample contains newly eligible decisions; full eventual deletion of this final cohort was not observed. sustained-B maintenance log follower attached before the app recreation and is partial; use deletion-counter time series, not that partial log, for its natural reclamation evidence.'})
(P/'sustained-storage-analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
for d in summary:print(d['point'],d['final'],[(x['name'],x['last']['n_tup_del']-x['first']['n_tup_del'],len(x['deletion_intervals'])) for x in d['tables']])
