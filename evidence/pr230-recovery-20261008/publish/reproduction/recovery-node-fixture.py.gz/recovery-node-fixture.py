from pathlib import Path
import urllib.request,hashlib,subprocess,json,time,datetime
R=Path('/src/evidence/pr230-recovery-20261008');d=R/'private-tools';name='node-v26.10.0-linux-x64.tar.xz';url='https://nodejs.org/dist/v26.10.0/';start=time.monotonic();checks=urllib.request.urlopen(url+'SHASUMS256.txt',timeout=30).read();expected=next(l.split()[0] for l in checks.decode().splitlines() if l.endswith(' '+name));data=urllib.request.urlopen(url+name,timeout=60).read();assert hashlib.sha256(data).hexdigest()==expected
(d/name).write_bytes(data);(d/'node-SHASUMS256.txt').write_bytes(checks);cmd=['tar','-xJf',str(d/name),'-C',str(d)];q=subprocess.run(cmd);assert q.returncode==0
version=subprocess.check_output([str(d/'node-v26.10.0-linux-x64/bin/node'),'--version'],text=True).strip();assert version=='v26.10.0'
record={'version':version,'url':url+name,'sha256':expected,'matches_official_shasums':True,'extract_command':cmd,'exit':0,'seconds':time.monotonic()-start,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};(R/'node-fixture.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
