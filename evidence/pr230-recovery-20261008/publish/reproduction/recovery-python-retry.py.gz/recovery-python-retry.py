from pathlib import Path
import subprocess,os,json,time,datetime,hashlib
R=Path('/src/evidence/pr230-recovery-20261008');env=dict(os.environ,**json.loads((R/'private-test-env.json').read_text()),PYTHONHOME='/opt/python314',LD_LIBRARY_PATH='/opt/python314/lib');env['PATH']='/opt/python314/bin:'+env['PATH'];sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
gates=json.loads((R/'final-gates.json').read_text());original=next(x for x in gates if x['label']=='perf-python');assert original['exit']==1
for label,cmd in [('python-orjson-fixture',['python','-m','pip','install','--only-binary=:all:','orjson==3.12.0']),('perf-python',original['command'])]:
 log=R/('final-'+label+'-retry.log');assert not log.exists();start=time.monotonic()
 with log.open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'sha':sha,'label':label,'command':cmd,'exit':r.returncode,'seconds':time.monotonic()-start,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'reason':'Install exact CI-pinned orjson in the Python3.14 isolated runner after genuine missing-dependency failures; source unchanged'}
 with (R/'commands.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
 if label=='perf-python':gates.append(rec);(R/'final-gates.json').write_text(json.dumps(gates,indent=2)+'\n')
 print(json.dumps(rec),log.read_text()[-3000:],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
