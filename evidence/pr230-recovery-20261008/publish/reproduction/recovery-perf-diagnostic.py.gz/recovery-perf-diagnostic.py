from pathlib import Path
import json,collections
R=Path('/src/evidence/pr230-recovery-20261008');out=[]
for key in ['p06-A','p06-B','p10-A','p10-B','p03-A','p03-B','p04-A','p04-B','sustained-A','sustained-B','p06-diagnostic']:
 roots=list((R/'perf'/key).glob('results/*/*/short-result.json'))
 if not roots:continue
 root=roots[0].parent;d=json.loads(roots[0].read_text());m=d['metrics']['measure'];lo=m['window_start_s'];hi=m['window_end_s'];sp=R/'perf'/key/'app-schedstat.jsonl';series=[json.loads(l) for l in sp.read_text().splitlines()] if sp.exists() else [];s=[x for x in series if lo<=x['ts']<=hi and x['exit']==0];sched={}
 if len(s)>1:
  a,b=s[0],s[-1];common=set(a['tasks'])&set(b['tasks']);delta=[sum(b['tasks'][k][i]-a['tasks'][k][i] for k in common) for i in range(3)];sched={'from':a['ts'],'to':b['ts'],'seconds':b['ts']-a['ts'],'same_threads':len(common),'runtime_s':delta[0]/1e9,'runnable_wait_s':delta[1]/1e9,'timeslices':delta[2]}
 pg=json.loads((root/'pgss-post.json').read_text());pre=json.loads((root/'pgss-pre.json').read_text());idx={(x['queryid'],x.get('userid'),x.get('toplevel')):x for x in pre['statements']};sql=[]
 for x in pg['statements']:
  if not x.get('toplevel'):continue
  a=idx.get((x['queryid'],x.get('userid'),x.get('toplevel')),{});n=x['calls']-a.get('calls',0);ms=x['total_exec_time']-a.get('total_exec_time',0)
  if n:sql.append({'query':x['q'],'role':x.get('rolname'),'calls':n,'mean_ms':ms/n,'total_ms':ms})
 sql.sort(key=lambda x:-x['total_ms']);out.append({'key':key,'cpu':d.get('component_cpu_cores'),'scheduler':sched,'sql_observation_seconds':float(pg['ts'])-float(pre['ts']),'top_sql':sql[:12],'pool_acquisition':d['cost'].get('wait_per_acq_ms'),'boundary':'scheduler is measured only inside the owned application, no host attribution; SQL interval includes warmup/drain and is not a per-formal-op cost; null pool acquisition means unmeasured'})
(R/'publish/perf-diagnostic.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps([{k:d.get(k) for k in ['key','cpu','scheduler','pool_acquisition']} for d in out],indent=2))
