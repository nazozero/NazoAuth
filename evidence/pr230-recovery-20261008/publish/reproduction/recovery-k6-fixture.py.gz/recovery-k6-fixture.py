from pathlib import Path
import json,subprocess,hashlib,time,datetime
R=Path('/src/evidence/pr230-recovery-20261008');d=R/'private-tools';d.mkdir(exist_ok=True);image=json.loads((R/'images.json').read_text())['runner_image'];assert image=='sha256:182d72b35f420f4d33d03388def1a789f8ad70c418d39ade0a9a4c05f954c3ab'
cmd=['docker','run','--rm','--network','none','--entrypoint','cat',image,'/usr/bin/k6'];start=time.monotonic();q=subprocess.run(cmd,capture_output=True);assert q.returncode==0;qpath=d/'k6';qpath.write_bytes(q.stdout);qpath.chmod(0o755)
record={'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-start,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'binary_sha256':hashlib.sha256(q.stdout).hexdigest(),'binary_bytes':len(q.stdout),'scope':'Copy exact already-used pinned performance runner k6; no extra checkout or host probe'}
(R/'k6-fixture.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
