# Replay the three-product machine-token comparison

Use the Linux Docker setup and CPU masks in TRANSACTION-REPLAY.md. Follow that file through the `bash build.sh` step under `transaction-comparison/` to provision all three products and build the NazoAuth release with its benchmark counter. Each product must have its own database, and the supported product CLI/API must create the clients and signing fixtures.

From `transaction-comparison/`, prepare the benchmark application containers with the previously supplied runner, then run this comparison.

```bash
bash run.sh probe
cd ../peer-comparison
python3 prepare-peers.py
bash run.sh
```

Only one application serves traffic at a time. The order rotates at 400 and 8,000 requests/s and again during the separate capacity searches. All windows use k6 2.1.0. The application, PostgreSQL, Valkey, generator and sampler keep the same CPU masks from the preceding replay. Valkey runs for NazoAuth.

The runner validates product-issued HTTP access tokens. NazoAuth additionally exposes the benchmark-only PostgreSQL acknowledgement counter. Each capacity confirmation requires three windows with zero failed responses and zero dropped arrivals, including warm-up. The runner records both stable rates and the observed throughput at the shared offered rate.

Read aggregate results from `peer-comparison/results/summary.json`. The archived tools exclude raw requests, event samples, TLS key material and private fixture inputs.

