# Machine-token benchmark replay

Use an isolated Linux amd64 Docker host with Bash, a C compiler supporting static
linking, Python 3, jq, OpenSSL, taskset and flock. The harness starts its own
private Docker network, test applications and databases. Set role CPU sets for
the host before starting. The defaults describe the original 64-logical-CPU
allocation. The 16 application CPUs must be on distinct physical cores. Keep
their SMT siblings out of the other role sets.

From the directory containing these scripts, prepare the two source inputs
using a NazoAuth clone with both revisions available.

    git -C "$repository" archive --format=tar --output="$PWD/baseline.tar" 00524936151549313999bf5a259289e25755f132
    git -C "$repository" diff --binary --output="$PWD/revision.patch" 00524936151549313999bf5a259289e25755f132 05a190a2dc21f37e0f3cd254ea80bf2f901a6b27
    bash build-release.sh
    bash retest.sh infra
    bash retest.sh apps
    bash retest.sh fixed
    bash retest.sh capacity
    bash recheck-nazo-machine.sh
    bash capacity-fallback.sh
    python3 report-retest.py results

Set BENCH_APP_CPUS, BENCH_PG_CPUS, BENCH_VK_CPUS, BENCH_K6_CPUS and
BENCH_CONTROL_CPU for a different host. Pass the same settings to each stage.
Application and dependency affinities are verified from thread masks during every
window. Docker names are reserved for this dedicated benchmark network.

The NazoAuth initialization volume is shared between each release binary's
provisioning commands and server process. Each database belongs to one product
or one NazoAuth variant. Products create clients, users and tokens through official
CLIs and HTTP APIs. Hydra imports the benchmark's 2048-bit signing configuration
through its admin key API. Hydra itself issues the measured tokens.

Fixed-rate runs use k6 2.1.0, with 10 seconds of warm-up and 20 seconds of
measurement. Capacity uses three confirming wrk2 windows at a tested rate.
The report and windows JSON include only aggregate measurements. The request
files and per-sample resource counters are temporary. The generated credentials
under private and in the fixture container are local to this isolated fixture.