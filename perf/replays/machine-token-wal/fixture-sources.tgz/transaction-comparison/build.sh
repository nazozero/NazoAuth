#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
umask 077
rust=docker.io/library/rust:1.100.0-slim@sha256:6f14b2b4b278ec0d50aa1d69541c304ce0f95e0f6268487aa9924af1c2e9aebe
container=hotpath-transaction-comparison-builder
mkdir -p out source
docker run -d --name "$container" -e RUSTUP_TOOLCHAIN=1.100.0 -e CARGO_BUILD_JOBS=22 "$rust" sleep infinity >/dev/null
trap 'docker rm -f "$container" >/dev/null 2>&1 || :' EXIT
docker exec "$container" mkdir -p /bench/src
docker exec "$container" rustc --version
for label in baseline transaction writer; do
  dir="source/$label"
  mkdir "$dir"
  tar -xf ../baseline.tar -C "$dir"
  if [[ $label != baseline ]]; then
    (cd "$dir" && git apply "../../$label.patch")
  fi
  python3 observe-commits.py "$dir"
  find "$dir" -type f \( -name '*.rs' -o -name Cargo.toml -o -name Cargo.lock \) -exec touch {} +
  tar -C "$dir" -cf - . | docker exec -i "$container" tar -xf - -C /bench/src
  docker exec -w /bench/src "$container" cargo build --locked --release -p nazo-server --bin nazoauth
  docker cp "$container:/bench/src/target/release/nazoauth" "out/nazoauth-$label"
  chmod 755 "out/nazoauth-$label"
  sha256sum "out/nazoauth-$label"
done
sha256sum transaction.patch writer.patch out/nazoauth-{baseline,transaction,writer} >out/identities.sha256
touch out/build-complete

