"""Add benchmark-only counters at PostgreSQL acknowledgement boundaries."""
from pathlib import Path
import sys

source = Path(sys.argv[1])

def replace(relative, before, after):
    path = source / relative
    content = path.read_text()
    assert content.count(before) == 1, (relative, before)
    path.write_text(content.replace(before, after))

postgres = "crates/persistence-postgres/src/"
path = source / (postgres + "lib.rs")
with path.open("a") as out:
    out.write('''
static BENCH_AUDIT_ROWS: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
static BENCH_AUDIT_COMMITS: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);

fn bench_count_audit(n: u64) {
    if n != 0 {
        use std::sync::atomic::Ordering::Relaxed;
        BENCH_AUDIT_ROWS.fetch_add(n, Relaxed);
        BENCH_AUDIT_COMMITS.fetch_add(1, Relaxed);
    }
}

pub fn bench_audit_observation() -> (u64, u64) {
    use std::sync::atomic::Ordering::Relaxed;
    (BENCH_AUDIT_ROWS.load(Relaxed), BENCH_AUDIT_COMMITS.load(Relaxed))
}
''')
replace(postgres + "repositories/token_issuance.rs",
        "                    match transaction {\n                        Ok(result) => Ok(result),\n",
        """                    match transaction {
                        Ok(result) => {
                            if result == CommitTokenIssuanceResult::Committed {
                                crate::bench_count_audit(1);
                            }
                            Ok(result)
                        }
""")
replace(postgres + "repositories/audit_ledger.rs",
        "                guard.return_to_pool();\n                return Ok(());\n",
        """                guard.return_to_pool();
                crate::bench_count_audit(u64::from(events[0].event_type == "token_issued"));
                return Ok(());
""")
replace(postgres + "repositories/audit_ledger.rs",
        """        guard.return_to_pool();
        Ok(())
    }

    /// Claim the single in-flight batch""",
        """        guard.return_to_pool();
        crate::bench_count_audit(events.iter().filter(|event| event.event_type == "token_issued").count() as u64);
        Ok(())
    }

    /// Claim the single in-flight batch""")
replace("crates/server/src/main.rs", "    nazo_server::cli::run(\n", """    #[cfg(unix)]
    if std::env::args().nth(1).as_deref() == Some("server") {
        use tokio::signal::unix::{SignalKind, signal};
        let mut observation = signal(SignalKind::user_defined1())?;
        tokio::spawn(async move {
            while observation.recv().await.is_some() {
                let (rows, commits) = nazo_postgres::bench_audit_observation();
                eprintln!("BENCH_AUDIT_DURABLE {rows} {commits}");
            }
        });
    }
    nazo_server::cli::run(
""")

