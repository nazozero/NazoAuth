#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
source <(awk '/^case /{exit} {print}' ../retest.sh)
runtime=nazoauth-hotpath-runtime:trixie
export prep

launch_label() {
  printf 'hotpath-txn-compare-%s' "$1"
}

run_point() {
  local label=$1 rate=$2 seconds=$3 outfile=$4 vus=960 name
  name=$(launch_label "$label")
  if [[ $rate == 400 ]]; then vus=64; fi
  if [[ $(docker inspect -f '{{.State.Running}}' "$name") != true ]]; then
    stop_comparison
    docker start "$name" >/dev/null
    ready "$name" /health
  fi
  (cd bench && BENCH_NAZO_CONTAINER=$name BENCH_VUS=$vus \
    bash comparison-point.sh nazo machine "$rate" 10 "$seconds" "$outfile")
}
export -f launch_label run_point ready

stop_comparison() {
  local label name
  for label in baseline transaction writer; do
    name=$(launch_label "$label")
    if [[ $(docker inspect -f '{{.State.Running}}' "$name" 2>/dev/null || :) == true ]]; then
      docker stop -t 8 "$name" >/dev/null
    fi
  done
}
export -f stop_comparison
trap stop_comparison EXIT

setup() {
  test -f out/build-complete
  stop_apps
  if [[ $(docker inspect -f '{{.State.Running}}' hotpath-nazo-durable 2>/dev/null || :) == true ]]; then
    docker stop -t 8 hotpath-nazo-durable >/dev/null
  fi
  docker start "$pg" "$vk" "$prep" oauthbench-k6 >/dev/null
  docker cp bench/durable-k6.js oauthbench-k6:/tmp/durable.js
  docker exec "$prep" cp /tmp/revised.json /tmp/nazo.json
  for label in baseline writer transaction; do
    name=$(launch_label "$label")
    if ! docker container inspect "$name" >/dev/null 2>&1; then
      docker create --name "$name" --network "$net" --network-alias oauthbench-api-audit \
        -v hotpath-nazo-data-revised:/var/lib/nazo_oauth \
        --log-opt max-size=16m --log-opt max-file=2 \
        --env-file ../private/revised.env -e RUST_LOG=warn \
        --entrypoint /affinity "$runtime" "$BENCH_APP_CPUS" /usr/local/bin/nazoauth server >/dev/null
      install_tools "$name"
      docker cp "out/nazoauth-$label" "$name:/usr/local/bin/nazoauth"
    fi
  done
}

setup
if [[ $# -gt 0 && $1 == probe ]]; then
  for label in baseline writer transaction; do
    run_point "$label" 400 12 "$ROOT/results/probe-$label.json"
    jq -e '.accepted and .whole_success == .durable_token_issued and .whole_success > 0' "$ROOT/results/probe-$label.json" >/dev/null
  done
else
  python3 benchmark.py "$ROOT/results"
fi

