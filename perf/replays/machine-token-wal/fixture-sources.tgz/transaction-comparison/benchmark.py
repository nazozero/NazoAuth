"""Rotate the three variants at common loads, then confirm separate capacity brackets."""
import json
from pathlib import Path
import subprocess
import sys

result_dir = Path(sys.argv[1])
variant_names = ["baseline", "writer", "transaction"]
results = {name: [] for name in variant_names}
out = result_dir / "summary.json"
capacity = {}
fixed = {}

def save(complete=False):
    path = out.with_suffix(".tmp")
    path.write_text(json.dumps({
        "complete": complete, "fixed_points": fixed, "capacity": capacity, "windows": results,
    }, indent=2) + "\n")
    path.replace(out)

def run(label, rate, kind, seconds, reattempt=False):
    trials = results[label]
    number = len(trials) + 1
    point_file = result_dir / f"{label}-{number:02d}-{rate}.json"
    if point_file.exists():
        point = json.loads(point_file.read_text())
        assert (point.get("experiment"), point["offered_per_second"], point["kind"]) == (label, rate, kind)
    else:
        command = ["bash", "-c", 'set -euo pipefail; run_point "$@"', "run-point",
                   label, str(rate), str(seconds), str(point_file)]
        subprocess.run(command, check=True)
        point = json.loads(point_file.read_text())
        point.update(experiment=label, kind=kind, window=number)
        point_file.write_text(json.dumps(point, indent=2) + "\n")
    assert not point["accepted"] or point["whole_success"] == point["durable_token_issued"]
    trials.append(point)
    save()
    values = (label, kind, rate, point["outcome"], point.get("success_per_second"),
              point.get("whole_success"), point.get("durable_token_issued"), point.get("p95_ms"),
              point.get("p99_ms"), point.get("dropped_whole_trial"))
    print(*values, sep="\t", flush=True)
    if point["outcome"] in {"harness", "generator"}:
        if reattempt:
            raise RuntimeError(f"unusable data for {label} at {rate}")
        return run(label, rate, kind, seconds, reattempt=True)
    return point

def common(rate, seconds, phase, rotate):
    for i in range(3):
        k = (i + rotate) % len(variant_names)
        for label in variant_names[k:] + variant_names[:k]:
            run(label, rate, phase, seconds)

def establish_capacity(label):
    grid = [2000, 3000, 4375, 5000, 6000, 7000, 8000, 10000, 12000, 14000, 16000, 20000]
    by_rate = {}
    for trial in results[label]:
        if trial["kind"] == "common-8000" and trial["outcome"] not in {"harness", "generator"}:
            by_rate.setdefault(trial["offered_per_second"], []).append(trial)

    def at_rate(rate):
        attempts = by_rate.setdefault(rate, [])
        if any(not point["accepted"] for point in attempts):
            return False
        while len(attempts) < 3:
            attempts.append(run(label, rate, "capacity", 36))
            if not attempts[-1]["accepted"]:
                return False
        return True

    ceiling = 8000 if not all(p["accepted"] for p in by_rate[8000]) else None
    best = None if ceiling else 8000
    if best:
        for rate in [12000, 16000, 20000]:
            if not at_rate(rate):
                ceiling = rate
                break
            best = rate
    else:
        for rate in [6000, 4375, 3000, 2000, 1000, 400]:
            if at_rate(rate):
                best = rate
                break
            ceiling = rate
    if best is None:
        raise RuntimeError(f"no stable capacity rate for {label}")
    if ceiling:
        between = [rate for rate in grid if best < rate < ceiling]
        while between:
            mid = len(between) // 2
            rate = between[mid]
            if at_rate(rate):
                best = rate
                between = between[mid + 1:]
            else:
                ceiling = rate
                between = between[:mid]
    capacity[label] = {
        "confirmed_rate": best,
        "nearest_rejected_rate": ceiling,
        "confirmation_windows": [trial["window"] for trial in by_rate[best]],
    }
    save()
    print(label, "capacity confirmed", capacity[label], flush=True)

common(400, 20, "common-400", 0)
for label in variant_names:
    passing = [p for p in results[label] if p["accepted"] and p["kind"] == "common-400"]
    while len(passing) < 3 and sum(p["kind"] == "fixed-retry" for p in results[label]) < 3:
        p = run(label, 400, "fixed-retry", 20)
        if p["accepted"]:
            passing.append(p)
    if len(passing) < 3:
        raise RuntimeError(f"fixed low-rate evidence incomplete for {label}")
    fixed[label] = [p["window"] for p in passing]
common(8000, 36, "common-8000", 1)
for label in ["baseline", "transaction", "writer"]:
    establish_capacity(label)
save(complete=True)

