import http from 'k6/http';
import exec from 'k6/execution';
import { Counter, Gauge, Trend } from 'k6/metrics';

const lines = open('/tmp/k6-request').split('\n');
const method = lines[0];
const path = lines[1];
const expected = Number(lines[2]);
const count = Number(lines[4]);
const headers = {};
for (let i = 0; i < count; i++) {
  headers[lines[5 + 2 * i]] = lines[6 + 2 * i];
}
const body = lines.slice(5 + 2 * count).join('\n');
const target = 'http://' + __ENV.BENCH_IP + ':' + __ENV.BENCH_PORT + path;
const rate = Number(__ENV.BENCH_RATE);
const warm = Number(__ENV.BENCH_WARM);
const seconds = Number(__ENV.BENCH_SECONDS);
const issued = __ENV.BENCH_CASE === 'machine';
const success = new Counter('measured_success');
const failure = new Counter('measured_failure');
const allSucceeded = new Counter('whole_success');
const allFailed = new Counter('whole_failure');
const vus = Number(__ENV.BENCH_VUS);
const scenarioStarted = new Gauge('scenario_started_unix_ms');
const latency = new Trend('successful_operation_ms', true);

export const options = {
  summaryTrendStats: ['med', 'p(95)', 'p(99)'],
  scenarios: {
    hotpath: {
      executor: 'constant-arrival-rate',
      rate,
      timeUnit: '1s',
      duration: String(warm + seconds) + 's',
      gracefulStop: '6s',
      preAllocatedVUs: vus,
      maxVUs: vus === 64 ? 512 : vus,
    },
  },
};

export default function () {
  const start = Number(exec.scenario.startTime);
  const requestStarted = Date.now();
  const response = http.request(method, target, body, {headers, timeout: '5s', redirects: 0});
  let passed = false;
  try {
    const parsed = response.json();
    passed = response.status === expected && (issued
      ? typeof parsed.access_token === 'string' && parsed.access_token.length > 0
      : parsed.active === true);
  } catch (_) {}
  allSucceeded.add(passed ? 1 : 0);
  allFailed.add(passed ? 0 : 1);
  if (requestStarted < start + warm * 1000 || requestStarted >= start + (warm + seconds) * 1000) {
    return;
  }
  scenarioStarted.add(start);
  if (passed) {
    success.add(1);
    latency.add(response.timings.blocked + response.timings.duration);
  } else {
    failure.add(1);
  }
}

export function handleSummary(data) {
  return {'/tmp/k6-window.json': JSON.stringify({workload: {rate, warm, seconds}, metrics: data.metrics})};
}