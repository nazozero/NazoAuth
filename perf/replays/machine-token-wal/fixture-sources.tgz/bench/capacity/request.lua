-- Drive one repeatable HTTP operation at a time. Request files are private.
local threads = {}
local expected_status
local expected_body
local raw_request

function setup(thread)
    threads[#threads + 1] = thread
end

function init(args)
    local fixture = assert(io.open(args[1], "rb"))
    local method = assert(fixture:read("*l"))
    local path = assert(fixture:read("*l"))
    expected_status = assert(tonumber(fixture:read("*l")))
    expected_body = assert(fixture:read("*l"))
    local count = assert(tonumber(fixture:read("*l")))
    local headers = {}
    for _ = 1, count do
        local name = assert(fixture:read("*l"))
        headers[name] = assert(fixture:read("*l"))
    end
    local body = fixture:read("*a")
    fixture:close()
    if body == "" then
        body = nil
    end
    raw_request = wrk.format(method, path, headers, body)
    benchmark_ok = 0
    benchmark_bad = 0
end

function request()
    return raw_request
end

function response(status, headers, body)
    if status == expected_status and
       (expected_body == "" or (body and body:match(expected_body))) then
        benchmark_ok = benchmark_ok + 1
    else
        benchmark_bad = benchmark_bad + 1
    end
end

function done(summary, latency, requests)
    local ok = 0
    local bad = 0
    for _, thread in ipairs(threads) do
        ok = ok + (thread:get("benchmark_ok") or 0)
        bad = bad + (thread:get("benchmark_bad") or 0)
    end
    local err = summary.errors
    local socket_errors = err.connect + err.read + err.write + err.timeout
    io.write(string.format(
        "BENCH_RESULT\t%d\t%d\t%d\t%d\t%d\t%.3f\t%.3f\t%.3f\t%d\t%d\t%d\t%d\n",
        summary.duration, summary.requests, ok, bad, socket_errors,
        latency:percentile(50), latency:percentile(95), latency:percentile(99),
        err.connect, err.read, err.write, err.timeout
    ))
end
