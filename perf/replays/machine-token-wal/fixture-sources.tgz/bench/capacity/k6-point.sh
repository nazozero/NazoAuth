#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
bash fixed-point.sh "$1" "$2" "$3" 10 "$4" "$6"