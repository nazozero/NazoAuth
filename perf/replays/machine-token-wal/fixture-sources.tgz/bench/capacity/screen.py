"""Find and confirm a sustainable offered rate within the available run budget."""
import json
import os
import subprocess
import sys
import time
from pathlib import Path


PEER, CASE, OUTPUT = sys.argv[1:4]
DESTINATION = Path(OUTPUT)
DEADLINE = int(os.environ.get("BENCH_CAPACITY_DEADLINE", "0"))
MAX_RATE = int(os.environ.get("BENCH_WRK2_MAX_RATE", "131072"))
SCREEN_SECONDS = int(os.environ.get("BENCH_WRK2_SCREEN_SECONDS", "24"))
CONFIRM_SECONDS = 36
TIMER_RECHECK_SECONDS = 48
CONNECTIONS = 960
SEEDS = {"machine": 400, "introspect": 500, "discovery": 1000, "jwks": 1000, "userinfo": 500}
records = []
old_summary = DESTINATION / "summary.json"
prior = json.loads(old_summary.read_text()) if old_summary.is_file() else {}
earlier_trials = prior.get("earlier_trials", []) + prior.get("trials", [])


def write_summary(**fields):
    DESTINATION.mkdir(parents=True, exist_ok=True)
    document = {"peer": PEER, "case": CASE, "trials": records, **fields}
    if earlier_trials:
        document["earlier_trials"] = earlier_trials
    temporary = DESTINATION / "summary.tmp"
    temporary.write_text(json.dumps(document, indent=2) + "\n")
    temporary.replace(DESTINATION / "summary.json")


def record_trial(rate, confirm, seconds):
    if DEADLINE and time.time() + seconds + 22 >= DEADLINE:
        raise TimeoutError
    trial_id = len(records) + 1
    point_file_id = len(earlier_trials) + trial_id
    output = DESTINATION / f"point-{point_file_id:02d}-{rate}.json"
    completed = subprocess.run(["bash", os.getenv("BENCH_CAPACITY_POINT_SCRIPT", "capacity/point.sh"), PEER, CASE, str(rate), str(seconds), str(CONNECTIONS),
                                str(output)], check=False)
    if output.is_file():
        result = json.loads(output.read_text())
    else:
        result = {"peer": PEER, "case": CASE, "offered_per_second": rate, "accepted": False,
                  "outcome": "harness", "exit": completed.returncode}
    result.update(confirmation=confirm, point=trial_id, requested_seconds=seconds)
    if (result["outcome"] == "load" and result["duration_seconds"] >= seconds + 0.025
            and not result["http_failures"] and not result["socket_errors"] and result["p99_ms"] > 0
            and .99 * rate * seconds <= result["success"]
            and result["throughput_success_per_second"] < .99 * rate):
        result.update(outcome="harness", retry_reason="wrk2-timer-overrun")
    records.append(result)
    write_summary(status="running", confirmed_rate=None)
    return result


def trial(rate, confirm=False):
    seconds = CONFIRM_SECONDS if confirm else SCREEN_SECONDS
    result = record_trial(rate, confirm, seconds)
    if result["outcome"] == "harness" or (result["outcome"] == "generator" and len(records) == 1):
        result = record_trial(rate, confirm, TIMER_RECHECK_SECONDS if result.get("retry_reason") else seconds)
    return result


def main():
    recheck_rate = (prior.get("first_rejected_rate") if prior.get("status") == "timing-review"
                    and SCREEN_SECONDS == CONFIRM_SECONDS else None)
    rate = recheck_rate or int(os.environ.get("BENCH_WRK2_SEED", SEEDS[CASE]))
    passes = set()
    high = None
    stop = "search-ceiling"
    for _ in range(1 if recheck_rate else 3):
        point = trial(rate)
        if point["accepted"]:
            passes.add(rate)
            break
        if point["outcome"] in {"harness", "generator"}:
            write_summary(status=point["outcome"], confirmed_rate=None)
            return
        high = rate
        stop = point["outcome"]
        rate //= 2
    if not passes:
        write_summary(status="no-accepted-starting-rate", confirmed_rate=None, first_rejected_rate=high)
        return

    if high is None:
        for _ in range(8):
            candidate = min(MAX_RATE, 2 * max(passes))
            if candidate == max(passes):
                break
            point = trial(candidate)
            if point["accepted"]:
                passes.add(candidate)
                continue
            high, stop = candidate, point["outcome"]
            break

    if high and stop not in {"generator", "harness"}:
        for _ in range(3):
            low = max(passes)
            if high <= low * 1.06:
                break
            candidate = (low + high) // 2
            point = trial(candidate)
            if point["accepted"]:
                passes.add(candidate)
            else:
                high, stop = candidate, point["outcome"]
                if stop in {"generator", "harness"}:
                    break

    for candidate in sorted(passes, reverse=True)[:2]:
        confirmed = []
        for _ in range(3):
            point = trial(candidate, confirm=True)
            if not point["accepted"]:
                if point["outcome"] == "load":
                    high = min(high, candidate) if high else candidate
                    stop = point["outcome"]
                break
            confirmed.append(point["point"])
        if len(confirmed) == 3:
            status = "bounded" if high and stop == "load" else "lower-bound"
            write_summary(status=status, confirmed_rate=candidate,
                          bounding_observation=stop, first_rejected_rate=high, confirmation_points=confirmed)
            return
    write_summary(status="confirmation-failed", confirmed_rate=None, first_rejected_rate=high,
                  screening_pass=max(passes))


try:
    main()
except TimeoutError:
    write_summary(status="deadline", confirmed_rate=None)
