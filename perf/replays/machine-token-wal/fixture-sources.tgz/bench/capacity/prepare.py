"""Create one private wrk2 request from the live, API-prepared fixture."""
import base64
import hashlib
import json
import os
import secrets
import sys
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlsplit

from api import Api


HOSTS = {"nazo": "oauthbench-api-audit", "keycloak": "oauthbench-kc-flow", "hydra": "oauthbench-hydra-flow"}
REALM = "/realms/api-audit"
KC_OIDC = REALM + "/protocol/openid-connect"
PUBLIC_ISSUER = "http://localhost:8080"
FORM = "application/x-www-form-urlencoded"


class LoginForm(HTMLParser):
    action = None

    def handle_starttag(self, tag, attributes):
        values = dict(attributes)
        if tag == "form" and values.get("id") == "kc-form-login":
            self.action = values["action"]


def param(url, name):
    return parse_qs(urlsplit(url).query)[name][0]


def issuer_path(url):
    parsed = urlsplit(url)
    assert f"{parsed.scheme}://{parsed.netloc}" == PUBLIC_ISSUER, "unexpected OAuth issuer"
    return parsed.path + (f"?{parsed.query}" if parsed.query else "")


def b64(data):
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def user_tokens(product, public, token_path, config):
    account = config["users"][0]
    client_id = config["clients"]["oidc"]
    redirect = config["redirect_uri"]
    verifier = secrets.token_urlsafe(32)
    state = secrets.token_urlsafe(24)
    query = urlencode({"response_type": "code", "client_id": client_id, "redirect_uri": redirect,
                       "scope": "openid profile", "state": state, "nonce": secrets.token_urlsafe(24),
                       "code_challenge_method": "S256",
                       "code_challenge": b64(hashlib.sha256(verifier.encode("ascii")).digest())})
    auth_path = {"nazo": "/authorize", "keycloak": KC_OIDC + "/auth", "hydra": "/oauth2/auth"}[product]
    if product == "nazo":
        public.login(account)
    _, location, status = public.call("GET", auth_path + "?" + query, expected=(200, 302, 303))
    if product == "nazo":
        request_id = param(location, "request_id")
        _, location, _ = public.form("POST", "/authorize/decision",
            {"request_id": request_id, "decision": "approve", "csrf_token": public.cookies["nazo_oauth_csrf"]},
            expected=(302, 303))
    elif product == "keycloak":
        for _ in range(4):
            if status == 200 or not location or not location.startswith(PUBLIC_ISSUER + "/"):
                break
            _, location, status = public.call("GET", issuer_path(location), expected=(200, 302, 303))
        if status == 200:
            form = LoginForm()
            form.feed(public.last_body.decode("utf-8"))
            assert form.action, "Keycloak login form was missing"
            _, location, _ = public.form("POST", issuer_path(form.action),
                {"username": account["email"], "password": account["password"]}, expected=(302, 303))
    else:
        admin = Api(HOSTS[product], 8081)
        challenge = param(location, "login_challenge")
        login, _, _ = admin.call("PUT", "/admin/oauth2/auth/requests/login/accept?" + urlencode(
            {"login_challenge": challenge}), {"subject": account["email"], "remember": True, "remember_for": 3600})
        _, location, _ = public.call("GET", issuer_path(login["redirect_to"]), expected=(302, 303))
        challenge = param(location, "consent_challenge")
        consent, _, _ = admin.call("PUT", "/admin/oauth2/auth/requests/consent/accept?" + urlencode(
            {"consent_challenge": challenge}), {"grant_scope": ["openid", "profile"],
            "remember": True, "remember_for": 3600, "session": {"id_token": {"email": account["email"]}}})
        _, location, _ = public.call("GET", issuer_path(consent["redirect_to"]), expected=(302, 303))
    assert location and location.startswith(redirect + "?") and param(location, "state") == state
    issued, _, _ = public.form("POST", token_path,
        {"client_id": client_id, "client_secret": config["client_secrets"][client_id], "grant_type": "authorization_code",
         "code": param(location, "code"), "redirect_uri": redirect, "code_verifier": verifier})
    assert issued["access_token"] and issued["id_token"]
    return issued


def main():
    peer, case, fixture, output = sys.argv[1:]
    config = json.loads(Path(fixture).read_text())
    prefix = {"nazo": "", "keycloak": KC_OIDC, "hydra": "/oauth2"}[peer]
    token_path = prefix + "/token"
    discovery_path = (REALM if peer == "keycloak" else "") + "/.well-known/openid-configuration"
    api = Api(HOSTS[peer])
    method, headers, body = "GET", {"Accept": "application/json", "Host": "localhost:8080"}, ""
    if case in ("discovery", "jwks"):
        discovery, _, _ = api.call("GET", discovery_path)
        assert discovery["issuer"] == config["issuer"]
        path, pattern = discovery_path, '"issuer"%s*:'
        if case == "jwks":
            path, pattern = issuer_path(discovery["jwks_uri"]), '"keys"%s*:%s*%['
            jwks, _, _ = api.call("GET", path)
            assert jwks["keys"]
    elif case == "userinfo":
        issued = user_tokens(peer, api, token_path, config)
        headers["Authorization"] = "Bearer " + issued["access_token"]
        path = (KC_OIDC if peer == "keycloak" else "") + "/userinfo"
        userinfo, _, _ = api.call("GET", path, headers=headers)
        assert userinfo["sub"]
        pattern = '"sub"%s*:%s*"'
    elif case in ("machine", "introspect"):
        cid = config["clients"].get("machine_basic") or config["clients"]["machine"]
        basic = "Basic " + base64.b64encode(f"{cid}:{config['client_secrets'][cid]}".encode()).decode()
        fields = {"grant_type": "client_credentials", "scope": "profile"}
        if peer == "hydra":
            from hydra_signing import configure, require_selected
            configure(api)
        issued, _, _ = api.form("POST", token_path, fields, headers={"Authorization": basic})
        if peer == "hydra":
            require_selected(issued["access_token"])
        assert issued["token_type"].lower() == "bearer" and "profile" in issued["scope"].split()
        method, path, pattern = "POST", token_path, '"access_token"%s*:%s*"'
        headers.update({"Authorization": basic, "Content-Type": FORM})
        if case == "introspect":
            fields = {"token": issued["access_token"], "token_type_hint": "access_token"}
            pattern = '"active"%s*:%s*true'
            path = {"nazo": "/introspect", "keycloak": token_path + "/introspect",
                    "hydra": "/admin/oauth2/introspect"}[peer]
            if peer == "hydra":
                api = Api(HOSTS[peer], 8081)
                del headers["Authorization"]
            checked, _, _ = api.form("POST", path, fields, headers=headers)
            assert checked["active"] is True
        body = urlencode(fields)
    else:
        raise ValueError(case)

    lines = [method, path, "200", pattern, str(len(headers))]
    for header, value in headers.items():
        lines.extend((header, value))
    assert all("\r" not in line and "\n" not in line for line in lines)
    os.umask(0o077)
    Path(output).write_bytes(("\n".join(lines) + "\n" + body).encode("utf-8"))


if __name__ == "__main__":
    main()
