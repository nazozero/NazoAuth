"""Seal one wrk2 trial using the same resource samplers as the fixed matrix."""
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from observe import sample_cgroup_roles, sample_host_pressure, sample_resources


sample_dir, filename, peer, case, rate, connections, started, status = sys.argv[1:]
source, output = Path(sample_dir), Path(filename)
offered = int(rate)
start_ms = int(started)
result = {"peer": peer, "case": case, "offered_per_second": offered,
          "connections": int(connections), "accepted": False, "wrk2_exit": int(status),
          "scenario_started_unix_ms": start_ms}
metrics = [line.split("\t")[1:] for line in (source / "wrk.log").read_text().splitlines()
           if line.startswith("BENCH_RESULT\t")]
if len(metrics) == 1:
    duration_us, total, ok, bad, sockets = map(int, metrics[0][:5])
    p50, p95, p99 = [float(value) / 1000 for value in metrics[0][5:8]]
    if len(metrics[0]) == 12:
        result["socket_errors_by_type"] = dict(zip(("connect", "read", "write", "timeout"), map(int, metrics[0][8:])))
    seconds = duration_us / 1_000_000
    resource_start = start_ms + 10_000
    end = start_ms + duration_us // 1000
    resources = sample_resources(source, resource_start, end)
    pressure, sampled = sample_host_pressure(source / "host.jsonl", resource_start, end)
    shared = sample_cgroup_roles(source, resources, resource_start, end)
    required = {"app", "postgres", "generator"} | ({"valkey"} if peer == "nazo" else set())
    resource_ok = required <= resources.keys() and all(
        resources[role]["affinity_mismatches"] == 0 and resources[role].get("sampled_intervals", 0) >= 4
        for role in required)
    actual = ok / seconds if seconds > 0 else 0
    result.update(duration_seconds=seconds, completed=total, success=ok, http_failures=bad, socket_errors=sockets,
                  throughput_success_per_second=round(actual, 2), p50_ms=p50, p95_ms=p95, p99_ms=p99,
                  host_cpu_psi_pct=pressure, host_sample_seconds=sampled,
                  resources=resources, shared_cgroup_v1=shared)
    if result["wrk2_exit"] or not resource_ok or sampled < (seconds - 10) * .65 or total != ok + bad:
        reason = "harness"
    elif resources["generator"]["mean_cpu_cores"] >= 12:
        reason = "generator"
    elif bad or sockets or actual < .99 * offered or p99 <= 0:
        reason = "load"
    else:
        reason = "accepted"
    result["accepted"] = reason == "accepted"
    result["outcome"] = reason
else:
    result["outcome"] = "harness"
output.parent.mkdir(parents=True, exist_ok=True)
temporary = output.with_suffix(".tmp")
temporary.write_text(json.dumps(result, indent=2) + "\n")
os.replace(temporary, output)
print(json.dumps(result, separators=(",", ":")))
