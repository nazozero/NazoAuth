#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
source "$ROOT/topology.sh"
cd "$ROOT"
umask 077
peer=$1
scenario=$2
rate=$3
seconds=$4
connections=$5
out=$6
wrk=oauthbench-wrk2
prep=oauthbench-wrk2-fixture

case "$peer" in
  nazo) app=${BENCH_NAZO_CONTAINER:-oauthbench-api-audit} ;;
  keycloak) app=oauthbench-kc-flow ;;
  hydra) app=oauthbench-hydra-flow ;;
  *) exit 2 ;;
esac
port=8080
if [[ $peer == hydra && $scenario == introspect ]]; then port=8081; fi
ip=$(docker inspect -f "{{(index .NetworkSettings.Networks \"$NET\").IPAddress}}" "$app")
[[ -n $ip ]]

scratch=$(mktemp -d)
sampler=
cleanup() {
  if [[ -n $sampler ]]; then kill "$sampler" 2>/dev/null || :; wait "$sampler" 2>/dev/null || :; fi
  docker exec "$prep" rm -f /tmp/wrk-request >/dev/null 2>&1 || :
  docker exec "$wrk" rm -f /tmp/wrk-request >/dev/null 2>&1 || :
  rm -rf -- "$scratch"
}
trap cleanup EXIT

docker exec "$prep" /affinity "$CONTROL_CPU" python3 /tmp/prepare.py "$peer" "$scenario" "/tmp/$peer.json" /tmp/wrk-request >"$scratch/prepare.log" 2>&1 || { tail -12 "$scratch/prepare.log" >&2; exit 1; }
docker cp "$prep:/tmp/wrk-request" "$scratch/wrk-request"
docker cp "$scratch/wrk-request" "$wrk:/tmp/wrk-request"

n=$(((seconds + 4) / 2 + 1))
pids=()
monitor() {
  docker exec -u 0 -e OAUTH_BENCH_CGROUPS=1 "$1" /affinity "$CONTROL_CPU" /sample-cpu "$2" "$n" "$3" >"$scratch/$4.cpu.tsv" 2>"$scratch/$4.cgroup.tsv" &
  pids+=("$!")
}
monitor "$app" "$APP_CPUS" '' app
monitor "$PG" "$PG_CPUS" '' postgres
if [[ $peer == nazo ]]; then monitor "$VK" "$VK_CPUS" '' valkey; fi
monitor "$wrk" "$GEN_CPUS" wrk2 generator
taskset -c "$CONTROL_CPU" python3 flows/host-cpu-sample.py >"$scratch/host.jsonl" 2>"$scratch/host.err" &
sampler=$!
started=$(date +%s%3N)
status=0
args=(-t15 -c"$connections" -d"${seconds}s" -R"$rate" --timeout 5s --latency -s /tmp/request.lua)
timeout "$((seconds + 12))s" docker exec "$wrk" /affinity "$GEN_CPUS" /wrk2 "${args[@]}" "http://$ip:$port" -- /tmp/wrk-request >"$scratch/wrk.log" 2>&1 || status=$?
if (( status != 0 )); then tail -12 "$scratch/wrk.log" >&2; fi
if ((status == 124 || status == 137)); then docker exec "$wrk" killall wrk2 >/dev/null 2>&1 || :; fi
for pid in "${pids[@]}"; do wait "$pid" || :; done
kill "$sampler" 2>/dev/null || :
wait "$sampler" 2>/dev/null || :
sampler=
taskset -c "$CONTROL_CPU" python3 capacity/seal.py "$scratch" "$out" "$peer" "$scenario" "$rate" "$connections" "$started" "$status"
