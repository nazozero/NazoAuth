"""Summarize one constant-arrival-rate window and discard the samples."""
import json
from pathlib import Path
import sys
from observe import metrics, sample_cgroup_roles, sample_host_pressure

scratch, out, peer, case, rate, status = sys.argv[1:]
source, output = Path(scratch), Path(out)
offered = int(rate)
status = int(status)
result = {"peer": peer, "case": case, "generator": "k6", "offered_per_second": offered,
          "accepted": False, "outcome": "harness", "k6_exit": status}
window = source / "k6-window.json"
if window.is_file():
    doc = json.loads(window.read_text())
    if "scenario_started_unix_ms" in doc["metrics"]:
        result.update(metrics(doc, source))
        workload = result["workload"]
        started = result["scenario_started_unix_ms"] + workload["warm"] * 1000
        ended = started + workload["seconds"] * 1000
        pressure, sampled = sample_host_pressure(source / "host.jsonl", started, ended)
        resources = result["resources"]
        result.update(
            duration_seconds=workload["seconds"],
            throughput_success_per_second=result["success_per_second"],
            http_failures=result["failed"],
            host_cpu_psi_pct=pressure,
            host_sample_seconds=sampled,
            shared_cgroup_v1=sample_cgroup_roles(source, resources, started, ended),
        )
        required = {"app", "postgres", "generator"} | ({"valkey"} if peer == "nazo" else set())
        complete = required <= resources.keys() and all(
            resources[role]["affinity_mismatches"] == 0 and resources[role].get("sampled_intervals", 0) >= 4
            for role in required
        )
        if status or not complete or sampled < workload["seconds"] * .65:
            reason = "harness"
        elif resources["generator"]["mean_cpu_cores"] >= 12 or result["dropped_whole_trial"]:
            reason = "generator"
        elif result["failed"] or result["success"] < .99 * result["expected_measured"] or not result["p99_ms"]:
            reason = "load"
        else:
            reason = "accepted"
        result.update(outcome=reason, accepted=reason == "accepted")
output.parent.mkdir(parents=True, exist_ok=True)
temporary = output.with_suffix(".tmp")
temporary.write_text(json.dumps(result, indent=2) + "\n")
temporary.replace(output)