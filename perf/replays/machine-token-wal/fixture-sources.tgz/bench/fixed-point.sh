#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")" && pwd)
source "$ROOT/topology.sh"
cd "$ROOT"
umask 077
peer=$1
scenario=$2
rate=$3
warm=$4
seconds=$5
out=$6
prep=oauthbench-wrk2-fixture
case "$peer" in
  nazo) app=${BENCH_NAZO_CONTAINER:-oauthbench-api-audit} ;;
  keycloak) app=oauthbench-kc-flow ;;
  hydra) app=oauthbench-hydra-flow ;;
  *) exit 2 ;;
esac
port=8080
if [[ $peer == hydra && $scenario == introspect ]]; then port=8081; fi
ip=$(docker inspect -f "{{(index .NetworkSettings.Networks \"$NET\").IPAddress}}" "$app")
[[ -n $ip ]]
scratch=$(mktemp -d)
sampler=
cleanup() {
  if [[ -n $sampler ]]; then kill "$sampler" 2>/dev/null || :; wait "$sampler" 2>/dev/null || :; fi
  docker exec "$prep" rm -f /tmp/k6-request >/dev/null 2>&1 || :
  docker exec "$RUN" rm -f /tmp/k6-request /tmp/k6-window.json >/dev/null 2>&1 || :
  rm -rf -- "$scratch"
}
trap cleanup EXIT

docker exec "$prep" /affinity "$CONTROL_CPU" python3 /tmp/prepare.py "$peer" "$scenario" "/tmp/$peer.json" /tmp/k6-request
docker cp "$prep:/tmp/k6-request" "$scratch/request"
docker cp "$scratch/request" "$RUN:/tmp/k6-request"

n=$(((warm + seconds + 4) / 2 + 1))
pids=()
monitor() {
  docker exec -u 0 -e OAUTH_BENCH_CGROUPS=1 "$1" /affinity "$CONTROL_CPU" /sample-cpu "$2" "$n" "$3" >"$scratch/$4.cpu.tsv" 2>"$scratch/$4.cgroup.tsv" &
  pids+=("$!")
}
monitor "$app" "$APP_CPUS" '' app
monitor "$PG" "$PG_CPUS" '' postgres
if [[ $peer == nazo ]]; then monitor "$VK" "$VK_CPUS" '' valkey; fi
monitor "$RUN" "$GEN_CPUS" k6 generator
taskset -c "$CONTROL_CPU" python3 flows/host-cpu-sample.py >"$scratch/host.jsonl" 2>"$scratch/host.err" &
sampler=$!
status=0
timeout "$((warm + seconds + 15))s" docker exec "$RUN" /affinity "$GEN_CPUS" env GOMAXPROCS=15 /usr/bin/k6 \
  run -q --no-color -e "BENCH_IP=$ip" -e "BENCH_PORT=$port" -e "BENCH_CASE=$scenario" \
  -e "BENCH_RATE=$rate" -e "BENCH_WARM=$warm" -e "BENCH_SECONDS=$seconds" /tmp/retest.js >"$scratch/k6.log" 2>&1 || status=$?
if (( status != 0 )); then
  tail -8 "$scratch/k6.log" >&2
  docker exec "$RUN" killall k6 >/dev/null 2>&1 || :
fi
for pid in "${pids[@]}"; do wait "$pid" || :; done
kill "$sampler" 2>/dev/null || :
wait "$sampler" 2>/dev/null || :
sampler=
docker cp "$RUN:/tmp/k6-window.json" "$scratch/k6-window.json" >/dev/null 2>&1 || :
taskset -c "$CONTROL_CPU" python3 fixed-seal.py "$scratch" "$out" "$peer" "$scenario" "$rate" "$status"