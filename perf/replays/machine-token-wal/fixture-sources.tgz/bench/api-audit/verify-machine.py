"""Verify one native machine grant and record public JWT parameters."""
import base64
import json
import sys
from pathlib import Path

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa

from api import Api, compact


def b64url_decode(value):
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def public_key_number(value):
    return int.from_bytes(b64url_decode(value), "big")


peer = sys.argv[1]
root = Path("/tmp")
fixture = json.loads((root / "state.json").read_text())
hosts = {"nazo": "oauthbench-api-audit", "keycloak": "oauthbench-kc-flow", "hydra": "oauthbench-hydra-flow"}
paths = {"nazo": ("/token", "/jwks.json"),
         "keycloak": ("/realms/api-audit/protocol/openid-connect/token",
                      "/realms/api-audit/protocol/openid-connect/certs"),
         "hydra": ("/oauth2/token", "/.well-known/jwks.json")}
api = Api(hosts[peer])
token_path, jwks_path = paths[peer]
client = fixture["clients"].get("machine_basic") or fixture["clients"]["machine"]
secret = fixture["client_secrets"][client]
authorization = "Basic " + base64.b64encode(f"{client}:{secret}".encode()).decode()
issued, _, _ = api.form("POST", token_path, {"grant_type": "client_credentials", "scope": "profile"},
                        headers={"Authorization": authorization})
header, payload, signature = issued["access_token"].split(".")
claims = json.loads(b64url_decode(payload))
protected = json.loads(b64url_decode(header))
assert protected["alg"] == "RS256" and claims["iss"] == fixture["issuer"]
assert issued["token_type"].lower() == "bearer" and "profile" in issued["scope"].split()
jwks, _, _ = api.call("GET", jwks_path)
jwk = next(key for key in jwks["keys"] if key["kid"] == protected["kid"])
key = rsa.RSAPublicNumbers(public_key_number(jwk["e"]), public_key_number(jwk["n"])).public_key()
key.verify(b64url_decode(signature), f"{header}.{payload}".encode(), padding.PKCS1v15(), hashes.SHA256())
proof = {"peer": peer, "signature": "RS256", "rsa_bits": key.key_size,
         "ttl_seconds": claims["exp"] - claims["iat"], "requested_scope": "profile",
         "returned_scope": sorted(issued["scope"].split()), "signature_verified": True}
(root / "machine-provenance.json").write_text(compact(proof))
print(compact(proof))
