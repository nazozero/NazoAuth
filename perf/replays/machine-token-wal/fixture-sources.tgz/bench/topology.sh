#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
NET=oauthbench26
PG=oauthbench-pg
VK=oauthbench-valkey
RUN=oauthbench-k6
APP_CPUS="${BENCH_APP_CPUS:-28,30,32,34,36,38,40,42,44,46,48,50,52,54,56,58}"
PG_CPUS="${BENCH_PG_CPUS:-60-73}"
VK_CPUS="${BENCH_VK_CPUS:-74-75}"
GEN_CPUS="${BENCH_K6_CPUS:-76-90}"
CONTROL_CPU="${BENCH_CONTROL_CPU:-27}"
probe() { docker exec "$RUN" /affinity "$CONTROL_CPU" wget -qO- --timeout=4 "$@"; }
