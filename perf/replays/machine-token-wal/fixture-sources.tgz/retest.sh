#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
ROOT=$PWD
umask 077
export BENCH_APP_CPUS=${BENCH_APP_CPUS:-138,140,142,144,146,148,150,152,154,156,158,160,162,164,166,168}
export BENCH_PG_CPUS=${BENCH_PG_CPUS:-170-183}
export BENCH_VK_CPUS=${BENCH_VK_CPUS:-184-185}
export BENCH_K6_CPUS=${BENCH_K6_CPUS:-24-33,186-190}
export BENCH_CONTROL_CPU=${BENCH_CONTROL_CPU:-191}
net=oauthbench26
pg=oauthbench-pg
vk=oauthbench-valkey
prep=oauthbench-wrk2-fixture
wrk=oauthbench-wrk2
kc=oauthbench-kc-flow
hy=oauthbench-hydra-flow
nazo_base=hotpath-nazo-baseline
nazo_rev=hotpath-nazo-revised
pg_image=postgres@sha256:0115267ab5a509022df9319c77be365cef335adb71556c75f60f5360ee247e71
vk_image=valkey/valkey@sha256:bf09d58e96d6b4524a15396b65b242bbe18beebbcc15a04d8ee75ddac62fae0b
kc_image=quay.io/keycloak/keycloak@sha256:7e66a96e4739239070aeaf72e4c5decf0f7f682cfc725b9f7ea2b336eaba38b3
hy_image=oryd/hydra@sha256:ff67c7fb5f95074fa53374d41151713554960504b340cd3f95b09e65deaea2a9
app_image=nazoauth-hotpath-runtime:trixie
wrk_image=nazoauth-api-bench-wrk2:44a94c1
fixture_image=nazoauth-api-bench-fixtures
k6_image=grafana/k6@sha256:65c920dc067d5e2e00befbf982af6ad6ad0117034e8b1c65817c7975c52d4669
mkdir -p private results
exec 9>"$ROOT/run.lock"
flock -n 9

container_for() {
  case "$1" in
    baseline) printf '%s' "$nazo_base" ;;
    revised) printf '%s' "$nazo_rev" ;;
    keycloak) printf '%s' "$kc" ;;
    hydra) printf '%s' "$hy" ;;
    *) return 2 ;;
  esac
}
install_tools() {
  docker cp bench/build/affinity "$1:/affinity"
  docker cp bench/build/sample-cpu "$1:/sample-cpu"
}
stop_apps() {
  for c in "$nazo_base" "$nazo_rev" "$kc" "$hy"; do
    if [[ $(docker inspect -f '{{.State.Running}}' "$c" 2>/dev/null || :) == true ]]; then
      docker stop -t 8 "$c" >/dev/null
    fi
  done
}
ready() {
  local host=$1 path=$2
  for ((attempt=0;attempt<100;attempt++)); do
    [[ $(docker inspect -f '{{.State.Running}}' "$host") == true ]] || break
    if docker exec "$prep" /affinity "$BENCH_CONTROL_CPU" python3 -c \
      'from http.client import HTTPConnection; import sys; c=HTTPConnection(sys.argv[1],8080,timeout=2); c.request("GET",sys.argv[2],headers={"Host":"localhost:8080"}); assert c.getresponse().status==200' \
      "$host" "$path" >/dev/null 2>&1; then return 0; fi
    sleep 1
  done
  docker logs --tail 18 "$host" >&2
  return 1
}
start_product() {
  local label=$1 name
  name=$(container_for "$label")
  stop_apps
  case "$label" in
    baseline|revised)
      docker start "$vk" "$name" >/dev/null
      ready "$name" /health
      docker exec "$prep" cp "/tmp/$label.json" /tmp/nazo.json
      ;;
    keycloak)
      docker stop -t 4 "$vk" >/dev/null
      docker start "$name" >/dev/null
      ready "$name" /realms/api-audit/.well-known/openid-configuration
      ;;
    hydra)
      docker stop -t 4 "$vk" >/dev/null
      docker start "$name" >/dev/null
      ready "$name" /.well-known/openid-configuration
      ;;
  esac
}
generate_secrets() {
  if [[ -e private/secrets.env ]]; then return 0; fi
  for key in pg_password nazo_password keycloak_password hydra_password kc_secret hydra_secret pepper admin_password; do
    printf '%s=%s\n' "$key" "$(openssl rand -hex 24)"
  done >private/secrets.env
  printf 'signing_key=%s\n' "$(openssl rand -base64 32 | tr '+/' '-_' | tr -d '=\n')" >>private/secrets.env
}
prepare_tools() {
  mkdir -p bench/build
  cc -static -O2 -o bench/build/affinity bench/affinity.c
  cc -static -O2 -o bench/build/sample-cpu bench/sampler.c
  sed -i 's/nazo) app=oauthbench-api-audit/nazo) app=${BENCH_NAZO_CONTAINER:-oauthbench-api-audit}/' bench/capacity/point.sh
  sed -i 's/recheck_rate or SEEDS\[CASE\]/recheck_rate or int(os.environ.get("BENCH_WRK2_SEED", SEEDS[CASE]))/' bench/capacity/screen.py
  docker image inspect "$wrk_image" >/dev/null 2>&1 || docker build -f bench/capacity/Containerfile -t "$wrk_image" bench/capacity
  docker image inspect "$fixture_image" >/dev/null 2>&1 || docker build -f bench/Containerfile -t "$fixture_image" bench
  docker image inspect "$app_image" >/dev/null 2>&1 || docker build -f Containerfile.runtime -t "$app_image" bench
}
init_db_role() {
  local role=$1 password=$2
  # Database roles are infrastructure. Product data enters only through product CLI and HTTP APIs.
  docker exec -i "$pg" psql -v ON_ERROR_STOP=1 -U postgres -d postgres \
    -v role="$role" -v password="$password" <<'SQL' >/dev/null
SELECT format('CREATE ROLE %I LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT PASSWORD %L', :'role', :'password')
WHERE NOT EXISTS (SELECT FROM pg_roles WHERE rolname=:'role') \gexec
SQL
}
infra() {
  generate_secrets
  source private/secrets.env
  prepare_tools
  docker network inspect "$net" >/dev/null 2>&1 || docker network create "$net" >/dev/null
  if ! docker container inspect "$pg" >/dev/null 2>&1; then
    docker create --name "$pg" --network "$net" --shm-size 2g --entrypoint /affinity \
      -e POSTGRES_PASSWORD="$pg_password" "$pg_image" "$BENCH_PG_CPUS" \
      /usr/local/bin/docker-entrypoint.sh postgres -c max_connections=128 -c shared_buffers=1GB \
      -c max_wal_size=8GB -c checkpoint_timeout=5min -c checkpoint_completion_target=0.9 >/dev/null
    install_tools "$pg"
    docker start "$pg" >/dev/null
    for ((i=0;i<60;i++)); do
      if docker exec "$pg" pg_isready -h 127.0.0.1 -U postgres >/dev/null 2>&1; then break; fi
      sleep 1
    done
    docker exec "$pg" pg_isready -h 127.0.0.1 -U postgres
    init_db_role nazoauth "$nazo_password"
    init_db_role keycloak "$keycloak_password"
    init_db_role hydra "$hydra_password"
    docker exec "$pg" createdb -U postgres nazo_baseline_ready
    docker exec "$pg" createdb -U postgres nazo_revised_ready
    docker exec "$pg" createdb -U postgres --owner=keycloak keycloak_retest
    docker exec "$pg" createdb -U postgres --owner=hydra hydra_retest
  fi
  if ! docker container inspect "$vk" >/dev/null 2>&1; then
    docker create --name "$vk" --network "$net" --entrypoint /affinity "$vk_image" \
      "$BENCH_VK_CPUS" /usr/local/bin/docker-entrypoint.sh valkey-server --save '' --appendonly no >/dev/null
    install_tools "$vk"
    docker start "$vk" >/dev/null
  fi
  if ! docker container inspect "$prep" >/dev/null 2>&1; then
    docker create --name "$prep" --network "$net" --entrypoint /affinity "$fixture_image" "$BENCH_CONTROL_CPU" sleep infinity >/dev/null
    install_tools "$prep"
    for file in api.py provision.py provision-peer.py verify-machine.py; do docker cp "bench/api-audit/$file" "$prep:/tmp/$file"; done
    docker cp bench/capacity/prepare.py "$prep:/tmp/prepare.py"
    docker cp bench/capacity/hydra_signing.py "$prep:/tmp/hydra_signing.py"
    docker start "$prep" >/dev/null
  fi
  if ! docker container inspect "$wrk" >/dev/null 2>&1; then
    docker create --name "$wrk" --network "$net" --entrypoint /affinity "$wrk_image" "$BENCH_K6_CPUS" sleep infinity >/dev/null
    install_tools "$wrk"
    docker cp bench/capacity/request.lua "$wrk:/tmp/request.lua"
    docker start "$wrk" >/dev/null
  fi
  if ! docker container inspect oauthbench-k6 >/dev/null 2>&1; then
    docker create --name oauthbench-k6 --user 0:0 --network "$net" --entrypoint /affinity \
      "$k6_image" "$BENCH_K6_CPUS" sleep infinity >/dev/null
    install_tools oauthbench-k6
    docker cp bench/hotpath-k6.js oauthbench-k6:/tmp/retest.js
    docker start oauthbench-k6 >/dev/null
  fi
  docker exec oauthbench-k6 /affinity "$BENCH_CONTROL_CPU" /usr/bin/k6 version >results/k6-version.txt
  docker exec "$wrk" /affinity "$BENCH_CONTROL_CPU" sha256sum /wrk2 >results/wrk2-sha256.txt
  echo "Infrastructure ready"
}
product_config() {
  local label=$1
  local db=nazo_${label}_ready
  local vk_db=1
  local epoch=019c8ca2-30a6-7000-8000-00000000e101
  if [[ $label == revised ]]; then vk_db=2; epoch=019c8ca2-30a6-7000-8000-00000000e102; fi
  cat >"private/$label.env" <<EOF
BIND=0.0.0.0:8080
DATA_DIR=/var/lib/nazo_oauth
DEPLOYMENT_ID=machine-token-retest-$label
ISSUER=http://localhost:8080
PUBLIC_BASE_URL=http://localhost:8080
DATABASE_URL=postgresql://nazoauth:$nazo_password@$pg:5432/$db
DATABASE_MAX_CONNECTIONS=32
VALKEY_URL=redis://$vk:6379/$vk_db
VALKEY_STATE_EPOCH=$epoch
CLIENT_SECRET_PEPPER=$pepper
SIGNING_KEY_ENCRYPTION_KEY_ID=hotpath-test
SIGNING_KEY_ENCRYPTION_KEY=$signing_key
TRANSPORT_MODE=trusted-proxy
TRUSTED_PROXY_CIDRS=172.16.0.0/12
CLIENT_IP_HEADER_MODE=x-forwarded-for
MTLS_CERTIFICATE_SOURCE=rfc9440
COOKIE_SECURE=false
AVATAR_OBJECT_STORE=local
AUTHORIZATION_SERVER_PROFILE=oauth2-baseline
AUDIT_ANCHOR_MODE=disabled
SECURITY_AUDIT_REQUIRE_LEAST_PRIVILEGE=true
AUTH_RATE_LIMIT_MAX_REQUESTS=1000000000
TOKEN_RATE_LIMIT_MAX_REQUESTS=1000000000
TOKEN_MANAGEMENT_RATE_LIMIT_MAX_REQUESTS=1000000000
ACCESS_TOKEN_TTL_SECONDS=300
RUST_LOG=warn
EOF
  printf '{"schema":1,"email":"perf-admin@example.test","password":"%s"}\n' "$admin_password" >private/admin.json
}
bootstrap_nazo() {
  local label=$1 name url init volume
  name=$(container_for "$label")
  init="hotpath-nazo-init-$label"
  url="postgresql://postgres:$pg_password@$pg:5432/nazo_${label}_ready"
  volume=hotpath-nazo-data-$label
  docker volume inspect "$volume" >/dev/null 2>&1 || docker volume create "$volume" >/dev/null
  product_config "$label"
  if ! docker container inspect "$name" >/dev/null 2>&1; then
    docker create --name "$name" --network "$net" --network-alias oauthbench-api-audit -v "$volume:/var/lib/nazo_oauth" \
      --log-opt max-size=16m --log-opt max-file=2 --env-file "private/$label.env" \
      --entrypoint /affinity "$app_image" "$BENCH_APP_CPUS" /usr/local/bin/nazoauth server >/dev/null
    install_tools "$name"
    docker cp "out/nazoauth-$label" "$name:/usr/local/bin/nazoauth"
  fi
  if [[ ! -e "results/$label-fixtures.json" ]]; then
    if ! docker container inspect "$init" >/dev/null 2>&1; then
      docker create --name "$init" --network "$net" --env-file "private/$label.env" -v "$volume:/var/lib/nazo_oauth" \
        --entrypoint /affinity "$app_image" "$BENCH_CONTROL_CPU" sleep infinity >/dev/null
      install_tools "$init"
      docker cp "out/nazoauth-$label" "$init:/usr/local/bin/nazoauth"
      docker start "$init" >/dev/null
    fi
    docker cp private/admin.json "$init:/admin.json"
    docker exec -e DATABASE_URL="$url" -e NAZOAUTH_MIGRATION_RUNTIME_ROLE=nazoauth "$init" \
      /affinity "$BENCH_CONTROL_CPU" /usr/local/bin/nazoauth migrate
    docker exec -e DATABASE_URL="$url" "$init" /affinity "$BENCH_CONTROL_CPU" /usr/local/bin/nazoauth tenant-bootstrap
    docker exec -e NAZOAUTH_ADMIN_PROVISION_FILE=/admin.json \
      -e NAZOAUTH_ADMIN_PROVISION_OPERATION_ID=hotpath-admin \
      -e NAZOAUTH_ADMIN_PROVISION_DEPLOYMENT_ID="machine-token-retest-$label" "$init" \
      /affinity "$BENCH_CONTROL_CPU" /usr/local/bin/nazoauth admin-provision >private/admin-receipt.json
    docker rm -f "$init" >/dev/null
    stop_apps
    docker start "$vk" "$name" >/dev/null
    ready "$name" /health
    docker cp private/admin.json "$prep:/tmp/api-bench-admin.json"
    docker exec "$prep" /affinity "$BENCH_CONTROL_CPU" python3 /tmp/provision.py
    docker exec "$prep" cp /tmp/state.json "/tmp/$label.json"
    docker exec "$prep" /affinity "$BENCH_CONTROL_CPU" python3 /tmp/verify-machine.py nazo >"results/$label-token-proof.json"
    docker cp "$prep:/tmp/provenance.json" "results/$label-fixtures.json"
    docker stop -t 8 "$name" >/dev/null
  fi
}
bootstrap_keycloak() {
  if [[ -e results/keycloak-fixtures.json ]]; then return 0; fi
  stop_apps
  docker stop -t 4 "$vk" >/dev/null
  if ! docker container inspect "$kc" >/dev/null 2>&1; then
    docker create --name "$kc" --network "$net" --entrypoint /affinity \
      -e KC_DB=postgres -e "KC_DB_URL=jdbc:postgresql://$pg:5432/keycloak_retest" \
      -e KC_DB_USERNAME=keycloak -e "KC_DB_PASSWORD=$keycloak_password" \
      -e KC_DB_POOL_MAX_SIZE=32 -e KC_BOOTSTRAP_ADMIN_CLIENT_ID=perf-bootstrap \
      -e "KC_BOOTSTRAP_ADMIN_CLIENT_SECRET=$kc_secret" \
      -e JAVA_OPTS_KC_HEAP='-Xms512m -Xmx4g' -e JAVA_OPTS_APPEND='-XX:ActiveProcessorCount=16' \
      "$kc_image" "$BENCH_APP_CPUS" /opt/keycloak/bin/kc.sh start --http-enabled=true --http-port=8080 \
      --hostname=http://localhost:8080 >/dev/null
    install_tools "$kc"
  fi
  docker start "$kc" >/dev/null
  ready "$kc" /realms/master/.well-known/openid-configuration
  printf '{"client_id":"perf-bootstrap","secret":"%s"}\n' "$kc_secret" >private/keycloak.json
  docker cp private/keycloak.json "$prep:/tmp/peer-bootstrap.json"
  docker exec "$prep" cp /tmp/baseline.json /tmp/state.json
  docker exec "$prep" /affinity "$BENCH_CONTROL_CPU" python3 /tmp/provision-peer.py keycloak >results/keycloak-fixtures.json.tmp
  docker exec "$prep" cp /tmp/peer-state.json /tmp/keycloak.json
  docker exec "$prep" cp /tmp/keycloak.json /tmp/state.json
  docker exec "$prep" /affinity "$BENCH_CONTROL_CPU" python3 /tmp/verify-machine.py keycloak >results/keycloak-token-proof.json
  mv results/keycloak-fixtures.json.tmp results/keycloak-fixtures.json
  docker stop -t 8 "$kc" >/dev/null
}
bootstrap_hydra() {
  if [[ -e results/hydra-fixtures.json ]]; then return 0; fi
  stop_apps
  docker stop -t 4 "$vk" >/dev/null
  local dsn="postgresql://hydra:$hydra_password@$pg:5432/hydra_retest?sslmode=disable&max_conns=32&max_idle_conns=32"
  if ! docker container inspect "$hy" >/dev/null 2>&1; then
    docker run --rm --network "$net" -e DSN="$dsn" "$hy_image" migrate sql up -e --yes
    docker create --name "$hy" --network "$net" --entrypoint /affinity \
      -e DSN="$dsn" -e SECRETS_SYSTEM="$hydra_secret" \
      -e URLS_SELF_ISSUER=http://localhost:8080 \
      -e URLS_LOGIN=https://fixture.example.test/login \
      -e URLS_CONSENT=https://fixture.example.test/consent \
      -e URLS_LOGOUT=https://fixture.example.test/logout \
      -e SERVE_PUBLIC_PORT=8080 -e SERVE_ADMIN_PORT=8081 \
      -e STRATEGIES_ACCESS_TOKEN=jwt -e TTL_ACCESS_TOKEN=5m -e LOG_LEVEL=warn \
      "$hy_image" "$BENCH_APP_CPUS" hydra serve all --dev >/dev/null
    install_tools "$hy"
  fi
  docker start "$hy" >/dev/null
  ready "$hy" /.well-known/openid-configuration
  docker exec "$prep" cp /tmp/baseline.json /tmp/state.json
  docker exec "$prep" /affinity "$BENCH_CONTROL_CPU" python3 /tmp/provision-peer.py hydra >results/hydra-fixtures.json.tmp
  docker exec "$prep" cp /tmp/peer-state.json /tmp/hydra.json
  docker exec "$prep" cp /tmp/hydra.json /tmp/state.json
  docker exec "$prep" /affinity "$BENCH_CONTROL_CPU" python3 /tmp/prepare.py hydra machine /tmp/hydra-preflight-request
  docker exec "$prep" rm -f /tmp/hydra-preflight-request
  docker exec "$prep" /affinity "$BENCH_CONTROL_CPU" python3 /tmp/verify-machine.py hydra >results/hydra-token-proof.json
  mv results/hydra-fixtures.json.tmp results/hydra-fixtures.json
  docker stop -t 8 "$hy" >/dev/null
}
point() {
  local label=$1 scenario=$2 rate=$3 warm=$4 seconds=$5 output=$6 peer=$1
  if [[ $label == baseline || $label == revised ]]; then peer=nazo; fi
  (cd bench && BENCH_NAZO_CONTAINER=$(container_for "$label") \
    bash fixed-point.sh "$peer" "$scenario" "$rate" "$warm" "$seconds" "$output" >/dev/null)
  jq -r '[.case,.offered_per_second,.outcome,.throughput_success_per_second,.p95_ms,.p99_ms,.host_cpu_psi_pct]|@tsv' "$output"
}
fixed() {
  local labels case rate order label round output
  for round in 1 2 3; do
    case $round in
      1) order='baseline revised keycloak hydra'; labels='machine introspect' ;;
      2) order='hydra keycloak revised baseline'; labels='introspect machine' ;;
      3) order='revised baseline hydra keycloak'; labels='machine introspect' ;;
    esac
    for label in $order; do
      start_product "$label"
      for case in $labels; do
        [[ $case == machine ]] && rate=400 || rate=500
        output="$ROOT/results/fixed/$label/$case/round-$round.json"
        [[ -s $output ]] && continue
        printf '%s round %s %s ' "$(date -u +%FT%TZ)" "$round" "$label"
        point "$label" "$case" "$rate" 10 20 "$output"
        if jq -e '.outcome == "harness"' "$output" >/dev/null; then
          point "$label" "$case" "$rate" 10 20 "${output%.json}-retry.json"
        fi
      done
    done
  done
  stop_apps
}
repair_fixed() {
  local label case rate round output active
  for label in baseline revised keycloak hydra; do
    active=
    for case in machine introspect; do
      [[ $case == machine ]] && rate=400 || rate=500
      for round in 1 2 3; do
        output="$ROOT/results/fixed/$label/$case/round-$round"
        if [[ -s $output.json ]] && jq -e '.accepted' "$output.json" >/dev/null; then continue; fi
        if [[ -s $output-retry.json ]] && jq -e '.accepted' "$output-retry.json" >/dev/null; then continue; fi
        if [[ -z $active ]]; then start_product "$label"; active=$label; fi
        if [[ -s $output-retry.json ]]; then mv "$output-retry.json" "$output-unaccepted-retry.json"; fi
        printf '%s repaired fixed round %s %s ' "$(date -u +%FT%TZ)" "$round" "$label"
        point "$label" "$case" "$rate" 10 20 "$output-retry.json"
      done
    done
  done
  stop_apps
}
capacity() {
  local case label peer seed dest
  repair_fixed
  for case in machine introspect; do
    if [[ $case == machine ]]; then order='revised baseline keycloak hydra'; else order='baseline revised hydra keycloak'; fi
    for label in $order; do
      dest="$ROOT/results/capacity/$label/$case"
      if [[ -s $dest/summary.json ]] && jq -e '.status != "running" and .status != "deadline"' "$dest/summary.json" >/dev/null; then continue; fi
      peer=$label
      if [[ $label == baseline || $label == revised ]]; then peer=nazo; fi
      case "$label/$case" in
        baseline/machine|revised/machine) seed=6400 ;;
        keycloak/machine) seed=12000 ;;
        hydra/machine) seed=400 ;;
        baseline/introspect|revised/introspect) seed=15000 ;;
        keycloak/introspect) seed=20000 ;;
        hydra/introspect) seed=3250 ;;
      esac
      start_product "$label"
      printf '%s capacity %s %s starting at %s\n' "$(date -u +%FT%TZ)" "$label" "$case" "$seed"
      (cd bench && BENCH_NAZO_CONTAINER=$(container_for "$label") BENCH_WRK2_SEED=$seed \
        taskset -c "$BENCH_CONTROL_CPU" python3 capacity/screen.py "$peer" "$case" "$dest") \
        >"results/capacity-$label-$case.log"
      jq -c '{status,confirmed_rate,first_rejected_rate,bounding_observation}' "$dest/summary.json"
    done
  done
  stop_apps
}
case "${1:-}" in
  infra) infra ;;
  apps)
    source private/secrets.env
    bootstrap_nazo baseline
    bootstrap_nazo revised
    bootstrap_keycloak
    bootstrap_hydra
    ;;
  fixed) fixed ;;
  probe-hydra) start_product hydra; point hydra machine 400 5 14 "$ROOT/results/hydra-k6-probe.json"; stop_apps ;;
  repair-fixed) repair_fixed ;;
  capacity) capacity ;;
  *) printf 'usage: %s {infra|apps|fixed|capacity}\n' "$0" >&2; exit 2 ;;
esac