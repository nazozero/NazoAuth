"""Render the same-host comparison from retained window summaries."""
from pathlib import Path
import json
import statistics
import sys


ROOT = Path(sys.argv[1])
VARIANTS = {
    "baseline": "NazoAuth before",
    "revised": "NazoAuth after",
    "keycloak": "Keycloak 26.8.2",
    "hydra": "Ory Hydra 26.2.0",
}
CASES = {"machine": ("Machine-token issuance", 400), "introspect": ("Active-token introspection", 500)}
ROLES = ("app", "postgres", "valkey", "generator")


def load(path):
    return json.loads(path.read_text()) if path.is_file() else None


def median(windows, key):
    return statistics.median(window[key] for window in windows)


def windows_for_fixed(variant, case):
    attempts, chosen = [], []
    for number in range(1, 4):
        base = ROOT / "fixed" / variant / case
        rows = [row for name in (f"round-{number}.json", f"round-{number}-unaccepted-retry.json", f"round-{number}-retry.json")
                if (row := load(base / name))]
        attempts.extend({"round": number, **row} for row in rows)
        for row in rows:
            if row["accepted"]:
                chosen.append({"round": number, **row})
                break
    return attempts, chosen


def capacity_selection(summary):
    if not summary:
        return []
    confirmed = set(summary.get("confirmation_points", []))
    windows = [window for window in summary["trials"] if window["point"] in confirmed]
    assert not windows or len(windows) == 3 and all(window["accepted"] for window in windows)
    return windows


def capacity_for(variant, case):
    path = Path(variant) / case / "summary.json"
    primary = load(ROOT / "capacity" / path) or {}
    earlier = load(ROOT / "capacity-first" / path) or {}
    highest = max((primary, earlier), key=lambda row: row.get("confirmed_rate") or 0)
    return highest, capacity_selection(highest), primary, earlier


def result_cell(windows, cap_status=None):
    if len(windows) < 3:
        states = {
            "no-accepted-starting-rate": "No qualifying rate",
            "confirmation-failed": "Confirmation failed",
            "harness": "Measurement blocked",
            "generator": "Load generator limited",
            "deadline": "Incomplete",
        }
        return states.get(cap_status, f"{len(windows)}/3 passing")
    throughput = median(windows, "throughput_success_per_second")
    p95, p99 = (median(windows, key) for key in ("p95_ms", "p99_ms"))
    prefix = "≥ " if cap_status == "lower-bound" else ""
    return f"{prefix}{throughput:,.1f} req/s · {p95:.2f}/{p99:.2f} ms"


def resources(windows, role):
    rows = [window["resources"][role] for window in windows if role in window["resources"]]
    if not rows:
        return "—"
    cpu = median(rows, "mean_cpu_cores")
    rss = max(row["max_single_process_rss_mib"] for row in rows)
    return f"{cpu:.2f} / {rss:.1f}"


def pressure(windows):
    values = [window["host_cpu_psi_pct"] for window in windows if window.get("host_cpu_psi_pct") is not None]
    return f"{min(values):.2f}–{max(values):.2f}%" if values else "—"


def table(columns, rows):
    return "\n".join(
        ["| " + " | ".join(columns) + " |", "| " + " | ".join(["---"] * len(columns)) + " |"]
        + ["| " + " | ".join(row) + " |" for row in rows]
    )


groups = {}
for variant in VARIANTS:
    for case in CASES:
        attempts, fixed = windows_for_fixed(variant, case)
        summary, capacity, primary, earlier = capacity_for(variant, case)
        fallback = load(ROOT / "capacity-k6" / variant / case / "summary.json") or {}
        groups[variant, case] = {
            "fixed_attempts": attempts, "fixed_selected": fixed,
            "capacity_summary": summary, "capacity_selected": capacity,
            "capacity_wrk2_latest": primary, "capacity_wrk2_first": earlier,
            "capacity_k6_fallback": fallback, "fallback_selected": capacity_selection(fallback),
        }

lines = [
    "# Machine-token benchmark retest", "",
    "Same-host comparison of native NazoAuth before and after the patch and two peer servers. "
    "Each result shows successful requests per second and the median P95/P99 in milliseconds over three passing windows. "
    "P95/P99 are the time within which approximately 95%/99% of measured requests completed.", "",
    "## Latency at the same request rate", "",
    table(("Operation", "Requested rate", *VARIANTS.values()), [
        (name, f"{rate} req/s", *(result_cell(groups[variant, case]["fixed_selected"]) for variant in VARIANTS))
        for case, (name, rate) in CASES.items()
    ]), "",
    "## Highest confirmed throughput", "",
    table(("Operation", *VARIANTS.values()), [
        (name, *(result_cell(groups[variant, case]["capacity_selected"],
                             groups[variant, case]["capacity_summary"].get("status"))
                 for variant in VARIANTS))
        for case, (name, _) in CASES.items()
    ]), "",
    "At capacity, each cell's latency is measured at its own confirmed rate. "
    "The ≥ prefix indicates a confirmed lower bound. A tested rate passes with at least 99% successful delivery, "
    "zero business or socket errors, complete affinity/resource observations and generator CPU below 12 cores.", "",
]
fallback_rows = [(variant, case, data) for (variant, case), data in groups.items()
                 if data["capacity_k6_fallback"]]
if fallback_rows:
    lines += [
        "## Alternate capacity check", "",
        "wrk2 timed out against Hydra's machine-token endpoint while k6 completed its fixed-rate control. "
        "These k6 rates use a different load shape and independent capacity confirmation.", "",
        table(("Operation", "Server", "k6 throughput · P95/P99"),
              [(CASES[case][0], VARIANTS[variant],
                result_cell(data["fallback_selected"], data["capacity_k6_fallback"]["status"]))
               for variant, case, data in fallback_rows]), "",
    ]
lines += ["## CPU, memory and host pressure", ""]
for stage in ("fixed", "capacity"):
    lines += [
        ("### Shared request rate" if stage == "fixed" else "### Capacity confirmation"), "",
        table(("Operation", "Server", "Target", "Next observed failure", "Application", "PostgreSQL",
               "Valkey", ("k6" if stage == "fixed" else "wrk2"), "Host CPU PSI"), [
            (name, product,
             str((rate if stage == "fixed" else groups[variant, case]["capacity_summary"].get("confirmed_rate")) or "—"),
             str((groups[variant, case]["capacity_summary"].get("first_rejected_rate") if stage == "capacity" else None) or "—"),
             *(resources(groups[variant, case][stage + "_selected"], role) for role in ROLES),
             pressure(groups[variant, case][stage + "_selected"]))
            for case, (name, rate) in CASES.items()
            for variant, product in VARIANTS.items()
        ]), "",
    ]
if fallback_rows:
    lines += [
        "### Alternate capacity check", "",
        table(("Operation", "Server", "Target", "Next observed failure", "Application", "PostgreSQL",
               "Valkey", "k6", "Host CPU PSI"),
              [(CASES[case][0], VARIANTS[variant],
                str(data["capacity_k6_fallback"].get("confirmed_rate") or "—"),
                str(data["capacity_k6_fallback"].get("first_rejected_rate") or "—"),
                *(resources(data["fallback_selected"], role) for role in ROLES),
                pressure(data["fallback_selected"]))
               for variant, case, data in fallback_rows]), "",
    ]
lines += [
    "Resource entries show mean logical CPU cores / peak single-process RSS in MiB. "
    "PostgreSQL RSS uses the largest observed process. CPU PSI reports the measured range of host scheduler pressure. "
    "The aggregate window data also includes network counters and shared cgroup v1 memory, throttling and block I/O.", "",
    "## Configuration and provenance", "",
    "- NazoAuth release builds use the same Rust 1.100.0 and Cargo lockfile, 005249361 before and 05a190a2d after.",
    "- AMD EPYC 9K65. Application 16 distinct physical cores with their SMT siblings excluded, PostgreSQL 14 logical CPUs, "
    "Valkey 2, wrk2 15, and sampling 1. The sampling CPU shares a core with a generator CPU.",
    "- PostgreSQL 18.7 with synchronous persistence and 1 GiB shared buffers, and Valkey 9.1.3 without periodic persistence. "
    "Each variant has a separate database and retains it across scenarios. Test data is created by official CLIs and HTTP APIs.",
    "- Machine issuance uses Basic client authentication and requests profile. Token proofs capture the product-issued "
    "RS256 signature and lifetime. The benchmark uses 2048-bit RSA, including Hydra's configuration via its key management API. "
    "Hydra introspection uses the private admin port.",
    "- Shared-rate trials use k6 2.1.0 at constant arrival rate, with 10 seconds of warm-up and 20 measured seconds. "
    "Latency includes connection blocking and the HTTP exchange. Admission applies at least 99% successful delivery, "
    "zero business failures or dropped iterations, complete resource observations and generator CPU below 12 cores.",
    "- Capacity uses wrk2 at 44a94c17d8e6a0bac8559b53da76848e430cb7a7, with 15 threads, 960 connections, "
    "24-second screening and three 36-second confirmations. Timing-error retries use up to 48 seconds. "
    "A paired NazoAuth machine recheck uses a shared 11,000 req/s starting point and 36-second screening; "
    "the highest three-window confirmation is reported and both rounds of evidence are retained.",
    "- NazoAuth uses a 32-connection application pool, a 300-second token lifetime and disabled external audit anchoring.",
    "",
]
aggregate = {f"{variant}/{case}": result for (variant, case), result in groups.items()}
(ROOT / "report.md").write_text("\n".join(lines), encoding="utf-8")
(ROOT / "windows.json").write_text(json.dumps(aggregate, indent=2) + "\n", encoding="utf-8")