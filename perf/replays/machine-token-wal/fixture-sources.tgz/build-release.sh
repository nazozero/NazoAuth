#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
rust=docker.io/library/rust:1.100.0-slim@sha256:6f14b2b4b278ec0d50aa1d69541c304ce0f95e0f6268487aa9924af1c2e9aebe
c=hotpath-release-builder
docker run -d --name "$c" -e RUSTUP_TOOLCHAIN=1.100.0 -e CARGO_BUILD_JOBS=22 "$rust" sleep infinity >/dev/null
trap 'docker rm -f "$c" >/dev/null 2>&1 || :' EXIT
docker exec "$c" mkdir -p /bench/src
sync_src() {
  tar -C src -cf - . | docker exec -i "$c" tar -xf - -C /bench/src
}
build() {
  docker exec -w /bench/src "$c" bash -ec 'rustc --version; cargo build --locked --release -p nazo-server --bin nazoauth'
  docker cp "$c:/bench/src/target/release/nazoauth" "out/nazoauth-$1"
  chmod 755 "out/nazoauth-$1"
  sha256sum "out/nazoauth-$1"
}
sync_src
build baseline
(cd src && git apply --check ../revision.patch && git apply ../revision.patch)
sync_src
build revised