#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
source <(sed '/^case "${1:-}" in/,$d' retest.sh)
for label in baseline revised; do
  dest="$ROOT/results/capacity/$label/machine"
  saved="$ROOT/results/capacity-first/$label/machine"
  if [[ ! -s $saved/summary.json ]]; then
    mkdir -p "$saved"
    cp "$dest/summary.json" "$saved/summary.json"
  fi
  start_product "$label"
  echo "$(date -u +%FT%TZ) machine recheck $label at 11000 req/s"
  (cd bench &&
    BENCH_NAZO_CONTAINER=$(container_for "$label") \
      BENCH_WRK2_SEED=11000 BENCH_WRK2_SCREEN_SECONDS=36 \
      taskset -c "$BENCH_CONTROL_CPU" python3 capacity/screen.py nazo machine "$dest") \
    >"results/capacity-$label-machine-recheck.log"
  jq -c '{status,confirmed_rate,first_rejected_rate,bounding_observation}' "$dest/summary.json"
done
stop_apps