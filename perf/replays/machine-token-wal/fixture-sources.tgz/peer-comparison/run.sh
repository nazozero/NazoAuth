#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
source <(awk '/^case /{exit} {print}' ../retest.sh)
nazo_peer=hotpath-txn-compare-transaction
export kc hy prep nazo_peer

candidate() {
  case "$1" in
    nazo) printf '%s' "$nazo_peer" ;;
    keycloak) printf '%s' "$kc" ;;
    hydra) printf '%s' "$hy" ;;
    *) return 2 ;;
  esac
}

stop_products() {
  local name
  for name in "$nazo_peer" "$kc" "$hy"; do
    if [[ $(docker inspect -f '{{.State.Running}}' "$name") == true ]]; then
      docker stop -t 8 "$name" >/dev/null
    fi
  done
}
trap stop_products EXIT

run_point() {
  local label=$1 rate=$2 seconds=$3 output=$4 name path vus=960
  name=$(candidate "$label")
  if [[ $rate == 400 ]]; then vus=64; fi
  if [[ $(docker inspect -f '{{.State.Running}}' "$name") != true ]]; then
    stop_products
    case "$label" in
      nazo)
        docker start oauthbench-valkey >/dev/null
        path=/health ;;
      keycloak)
        docker stop -t 4 oauthbench-valkey >/dev/null
        path=/realms/api-audit/.well-known/openid-configuration ;;
      hydra)
        docker stop -t 4 oauthbench-valkey >/dev/null
        path=/.well-known/openid-configuration ;;
    esac
    docker start "$name" >/dev/null
    ready "$name" "$path"
  fi
  (cd bench && BENCH_NAZO_CONTAINER="$nazo_peer" BENCH_VUS=$vus \
    bash peer-point.sh "$label" machine "$rate" 10 "$seconds" "$output")
}
export -f candidate stop_products run_point ready

stop_apps
docker start "$pg" "$prep" oauthbench-k6 >/dev/null
for _ in {1..60}; do
  if docker exec "$pg" pg_isready -h 127.0.0.1 -U postgres >/dev/null; then break; fi
  sleep 1
done
docker exec "$pg" pg_isready -h 127.0.0.1 -U postgres >/dev/null
docker cp bench/durable-k6.js oauthbench-k6:/tmp/durable.js
docker exec "$prep" cp /tmp/revised.json /tmp/nazo.json
python3 benchmark.py "$ROOT/results"

