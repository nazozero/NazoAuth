"""Compare three products with a single load generator and rotating time slots."""
import json
from pathlib import Path
import subprocess
import sys

dest = Path(sys.argv[1])
dest.mkdir(parents=True, exist_ok=True)
names = ["nazo", "keycloak", "hydra"]
windows = {name: [] for name in names}
fixed = {}
capacities = {}

def write(complete=False):
    temp = dest / "summary.tmp"
    temp.write_text(json.dumps(dict(complete=complete, fixed=fixed, capacities=capacities, windows=windows),
                               indent=2) + "\n")
    temp.replace(dest / "summary.json")

def test(name, target, seconds, phase, retry=True):
    index = len(windows[name]) + 1
    path = dest / f"{name}-{index:02d}-{target}.json"
    if not path.exists():
        subprocess.run(["bash", "-c", 'set -euo pipefail; run_point "$@"', "comparison-point",
                        name, str(target), str(seconds), str(path)], check=True)
        point = json.loads(path.read_text())
        point.update(index=index, phase=phase)
        path.write_text(json.dumps(point, indent=2) + "\n")
    else:
        point = json.loads(path.read_text())
        assert (point["peer"], point["offered_per_second"], point["index"], point["phase"]) == (
            name, target, index, phase)
    windows[name].append(point)
    write()
    print(name, phase, target, point["outcome"], point.get("success_per_second"),
          point.get("p95_ms"), point.get("p99_ms"), point.get("whole_success"),
          point.get("whole_failed"), point.get("dropped_whole_trial"), point.get("durable_token_issued"), flush=True)
    if point["outcome"] in {"harness", "generator"} and retry:
        return test(name, target, seconds, phase, retry=False)
    if point["outcome"] in {"harness", "generator"}:
        raise RuntimeError(f"invalid harness result at {name} {target}")
    return point

def rotate(target, seconds, phase, offset):
    for i in range(3):
        k = (i + offset) % len(names)
        for name in names[k:] + names[:k]:
            test(name, target, seconds, phase)

def capacity(name):
    grid = [400, 600, 800, 1000, 1200, 1600, 2000, 2400, 3000, 4375, 5000,
            6000, 7000, 8000, 10000, 12000, 14000, 16000]
    high = [p for p in windows[name] if p["phase"] == "common-8000" and p["outcome"] not in {"harness","generator"}]
    assert len(high) == 3
    attempts = {8000: high}

    def confirms(rate):
        points = attempts.setdefault(rate, [])
        while len(points) < 3 and all(p["accepted"] for p in points):
            points.append((yield rate))
        return len(points) == 3 and all(p["accepted"] for p in points)

    if all(p["accepted"] for p in high):
        best, rejected = 8000, None
        for rate in (12000, 16000):
            if not (yield from confirms(rate)):
                rejected = rate
                break
            best = rate
    else:
        best, rejected = None, 8000
        declines = [1200, 800, 400] if name == "hydra" else [6000, 4375, 3000, 2000, 1000, 400]
        for rate in declines:
            if (yield from confirms(rate)):
                best = rate
                break
            rejected = rate
    if best and rejected:
        for _ in range(3):
            middle = [r for r in grid if best < r < rejected]
            if not middle or rejected <= 1.10 * best:
                break
            choice = middle[len(middle) // 2]
            if (yield from confirms(choice)):
                best = choice
            else:
                rejected = choice
    return dict(confirmed_rate=best, nearest_rejection=rejected,
                ids=[p["index"] for p in attempts[best]] if best else [])

rotate(400, 20, "common-400", 0)
for name in names:
    passed = [p for p in windows[name] if p["phase"] == "common-400" and p["accepted"]]
    for _ in range(3 - len(passed)):
        point = test(name, 400, 20, "400-retry")
        if point["accepted"]:
            passed.append(point)
    fixed[name] = [p["index"] for p in passed]
write()
rotate(8000, 36, "common-8000", 1)
protocols = {name: capacity(name) for name in names}
next_target = {}
for name, protocol in protocols.items():
    try:
        next_target[name] = next(protocol)
    except StopIteration as out:
        capacities[name] = out.value
round_id = 0
while next_target:
    k = round_id % len(names)
    round_id += 1
    for name in names[k:] + names[:k]:
        if name not in next_target:
            continue
        point = test(name, next_target[name], 36, "capacity")
        try:
            next_target[name] = protocols[name].send(point)
        except StopIteration as out:
            capacities[name] = out.value
            next_target.pop(name)
            write()
            print("capacity", name, capacities[name], flush=True)
write(complete=True)

