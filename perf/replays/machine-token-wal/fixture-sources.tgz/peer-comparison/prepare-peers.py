"""Add peer runs to the same k6 and audit reconciliation harness."""
from pathlib import Path
from shutil import copytree

copytree("../transaction-comparison/bench", "bench", ignore=lambda _path, files: {"__pycache__"}.intersection(files))
source = Path("bench/comparison-point.sh").read_text()
for moment in ("before", "after"):
    original = f'snapshot >"$scratch/count-{moment}"'
    assert source.count(original) == 1
    source = source.replace(original, f'if [[ $peer == nazo ]]; then {original}; fi')
source = source.replace("python3 comparison-seal.py", "python3 peer-seal.py")
Path("bench/peer-point.sh").write_text(source)
source = Path("bench/comparison-seal.py").read_text()
a = source.index("        before_rows")
b = source.index("        totals =", a)
c = source.index("        result.update(whole_success")
d = source.index("        if status", c)
read = "".join("    "+line for line in source[a:b].splitlines(keepends=True))
source = (source[:a] + source[b:c]
          + "        result.update(whole_success=whole_success, whole_failed=whole_failed)\n"
          + "        if peer == \"nazo\":\n" + read
          + "            result.update(durable_token_issued=signatures, acknowledged_audit_transactions=batches,\n"
          + "                          audit_count_difference=signatures-whole_success)\n" + source[d:])
source = source.replace("elif not whole_success or signatures != whole_success:",
                        'elif peer == "nazo" and (not whole_success or signatures != whole_success):')
Path("bench/peer-seal.py").write_text(source)

