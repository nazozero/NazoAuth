# Replay the NazoAuth machine-token transaction comparison

Use a dedicated Linux amd64 Docker host with Bash, Python 3, jq, OpenSSL, taskset, flock and a C compiler that supports static linking. Assign 16 distinct physical cores to the application and leave their SMT siblings outside the dependency and load-generator sets. The original masks and override variables are in REPLAY.md. Keep other workloads off those CPUs during the experiment.

Extract this archive into a new directory. Prepare the original fixture with a NazoAuth clone containing the revisions below. The SQL database and roles are infrastructure. Clients, users and tokens are created through the product CLI and HTTP APIs.

```bash
repository=/path/to/NazoAuth
git -C "$repository" archive --format=tar --output="$PWD/baseline.tar" 00524936151549313999bf5a259289e25755f132
git -C "$repository" diff --binary --output="$PWD/revision.patch" 00524936151549313999bf5a259289e25755f132 05a190a2dc21f37e0f3cd254ea80bf2f901a6b27
git -C "$repository" diff --binary --output="$PWD/transaction-comparison/writer.patch" 00524936151549313999bf5a259289e25755f132 c1a6b98106e9df10fcb24925c5e989d243cb4a42
git -C "$repository" diff --binary --output="$PWD/transaction-comparison/transaction.patch" 00524936151549313999bf5a259289e25755f132 f6f1f9a08d1614f9af42088292d07598ad5073d7
mkdir src out
tar -xf baseline.tar -C src
bash build-release.sh
bash retest.sh infra
bash retest.sh apps
cp -an bench/. transaction-comparison/bench/
cd transaction-comparison
bash build.sh
bash run.sh all
```

The runner uses one product-provisioned database and client for all three variants. The variants run one at a time and rotate order at the two common rates. Each window uses ten seconds of warm-up. The 400 requests/s comparison measures twenty seconds and the capacity windows measure thirty-six seconds. k6 drains in-flight requests before reconciliation.

The benchmark builds add two atomic counters after the PostgreSQL commit boundaries. The runner samples the counters on both sides of each timed operation through a benchmark-only SIGUSR1 handler. Product traffic uses only HTTP. Each passing window has matching successful responses and committed audit events, zero failed requests, zero dropped arrivals, and valid affinity and resource samples. Instrumentation is present only in the benchmark binaries.

Results are saved as aggregate JSON in `transaction-comparison/results/`. The `summary.json` file identifies the selected windows and includes excluded window summaries. Per-request samples and private fixture inputs are temporary or stay within the replay environment.

