#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
# Load the same lifecycle and CPU assignments as the primary runner.
source <(sed '/^case "${1:-}" in/,$d' retest.sh)
for scenario in machine introspect; do
  result="$ROOT/results/capacity/hydra/$scenario/summary.json"
  if [[ -s $result ]] && jq -e '.confirmed_rate != null' "$result" >/dev/null; then continue; fi
  if [[ $scenario == machine ]]; then seed=400; else seed=3250; fi
  start_product hydra
  (cd bench && BENCH_CAPACITY_POINT_SCRIPT=capacity/k6-point.sh BENCH_WRK2_SEED=$seed \
    taskset -c "$BENCH_CONTROL_CPU" python3 capacity/screen.py hydra "$scenario" "$ROOT/results/capacity-k6/hydra/$scenario") \
    >"results/capacity-k6-hydra-$scenario.log"
  jq -c '{case,status,confirmed_rate,first_rejected_rate}' "results/capacity-k6/hydra/$scenario/summary.json"
done
stop_apps